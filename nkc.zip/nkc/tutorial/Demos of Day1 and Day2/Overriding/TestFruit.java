package Overriding;

public class TestFruit
{
public static void main(String arr[])
{
	Fruit a1=new Apple("Kashmir Apple","Very Sweet",'S');
	a1.eat();
//	Apple a2=new Apple("local Apple","less Sweet",'M');
//	Orange o1=new Orange("Nagpur orange","Very Sweet",'L');
//	Orange o2=new Orange("local orange","Very Sour",'S');
//	Fruit f=new Fruit();
//	f.eat();
//	f=a1;	f.eat();
//	f=a2;	f.eat();
//	f=o1;	f.eat();
//	f=o2;	f.eat();
}
}