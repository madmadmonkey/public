package Overriding;

import java.io.EOFException;
import java.io.FileNotFoundException;

public class Orange extends Fruit
{
	public Orange(String name, String taste, char size)
	{
		super(name,taste,size);
	}
	public void eat () {
		System.out.println("Name of Fruit is: "+getName());
		System.out.println("Taste of Fruit is: "+getTaste());
		System.out.println("Size of Fruit is: "+getSize());
		System.out.println();	
	}
}