package Overriding;


public class Apple extends Fruit
{
	public Apple(String name, String taste, char size)
	{
		super(name,taste,size);
	}
	public void eat()
	{
		System.out.println("Name of Fruit is: "+getName());
		System.out.println("Taste of Fruit is: "+getTaste());
		System.out.println("Size of Fruit is: "+getSize());
		System.out.println();
	}
	
public void juice() {
		
	}
}