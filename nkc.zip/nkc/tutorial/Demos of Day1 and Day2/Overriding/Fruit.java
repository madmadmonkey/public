package Overriding;

import java.io.IOException;

class Fruit
{
	private String name;
	private String taste;
	private char size;
	Fruit()
	{
		
	}
	Fruit(String name, String taste, char size)
	{
		this.name=name;
		this.taste=taste;
		this.size=size;
	}
	public String getName()
	{	return name;	}
	public String getTaste()
	{	return taste;	}
	public char getSize()
	{	return size;	}
	public void eat () 
	{
		System.out.println("name" +name );
		System.out.println("taste" + taste);
		System.out.println("size"  +size);
		System.out.println();
	}	

}