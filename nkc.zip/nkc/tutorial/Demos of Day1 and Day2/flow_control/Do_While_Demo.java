package flow_control;

import java.util.Scanner;

public class Do_While_Demo {
	 public static void main(String[] args) {
		   
	      double number, sum = 0.0;
	      Scanner input = new Scanner(System.in);

	      do {
	    	 System.out.print("Enter a number: ");
	    	 number = input.nextDouble();
	    	 sum += number;
	      } while (number != 0.0);
		   
	      System.out.println("Sum = " + sum);
	   }
}
