package flow_control;

public class If_Demo {
	public static void main(String[] args) {
		int x = 10;
		if(x>10)
		{
			System.out.println("I am greater than 10");
		}
		else{
			System.out.println("I am less than 10");
		}
	}

}
