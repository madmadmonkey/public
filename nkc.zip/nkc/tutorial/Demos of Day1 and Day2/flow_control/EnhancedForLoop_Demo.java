package flow_control;

public class EnhancedForLoop_Demo {

		  public static void main(String[] args) {
		    int primes[] = { 2, 3, 5, 7, 11, 13, 17, 19, 23, 29};
		 
		    for (int t: primes) {
		      System.out.println(t); 
		    }
		  }
		}

