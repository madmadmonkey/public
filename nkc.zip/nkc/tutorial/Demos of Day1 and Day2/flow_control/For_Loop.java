package flow_control;

public class For_Loop {
	 public static void main(String args[]) {
		 int y=0;
	      for(int x = 10; x < 20; x = x + 1) {
	         System.out.print("value of x : " + x );
	         System.out.print("\n");
	      }
	      
//	      for(;;y++ )
//	      {
//	    	  if(y==7)
//	    	  {
//	    		  System.out.println("yayy, we reached the last iteration");
//	    		  break;
//	    	  }
	    	  
//	      }
	      
	      for(;y<8; )
	      {
	    	  if(y==7)
	    	  {
	    		  System.out.println("yayy, we reached the last iteration");
	    		  
	    	  }
	    	  y++;
	      }
	   }
}
