package flow_control;

public class While_Demo {
	 public static void main(String[] args) {
	      
	      int i = 1;
		   
	      while (i <= 10) {
	         System.out.println("Line " + i);
	         ++i;
	      }
	   }
}
