package flow_control;

public class If_Demo2 {

		public static void main(String[] args) {
		
			
		int a =10; int b=5;
		System.out.println(++a+(++b));
		}

	
}

