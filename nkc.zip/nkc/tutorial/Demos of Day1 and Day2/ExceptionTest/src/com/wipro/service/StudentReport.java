package com.wipro.service;
import com.wipro.bean.Student;
import com.wipro.util.NullObjectException;
public class StudentReport {
	public String validate(Student obj) throws NullObjectException{
		if(obj == null)
		{
			NullObjectException e = new NullObjectException();
			throw e;
		}
		return "valid";
		
	}
	public String generateReport(Student obj){
		try{
		if(validate(obj).equals("valid"))
		{
			return "Student report is : "+obj.getName();
		}
		}catch(NullObjectException e){
			return e.toString();
		}
		return null;
		
	}
}
