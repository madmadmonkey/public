package com.wipro.util;

public class NullObjectException extends Exception {
	public String toString()
	{
		return "null object exception";
	}
}
