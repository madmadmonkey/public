package com.wipro.main;

import com.wipro.bean.Student;
import com.wipro.service.StudentReport;
import com.wipro.util.NullObjectException;

public class Tester {
public static void main(String[] args) {
	Student s = null;
	StudentReport report = new StudentReport();
	System.out.println(report.generateReport(s));
}
}
