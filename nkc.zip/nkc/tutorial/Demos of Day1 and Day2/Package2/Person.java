package Package2;

public class Person
{
	private String name;
	String id;
	public static int age=0;
	protected String address;
	
	public Person(){
		
	}
	public Person(String name)
	{
		this.name=name;
		this.age=9;
	}
	
	public static void sayHello() {
		System.out.println("hello, your age is " + age);
	}
	public static void displayAge()
	{
		System.out.println("the age is  "  + age );
	}
}