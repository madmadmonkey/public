package Package2;

public class PersonDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Person p = new Person("Wipro");
System.out.println(p.address);
	}

}
