package Abstract_Classes;

import java.util.LinkedList;

public class Arrays {
	public static void main(String[] args) {
		
		int[] array = {1,2,3,4,6,7,8,8,90,45,3,5,3};
		int total=array.length;
		int k =0;

	for(int i =0; i<array.length;i++)
		{
			for(int j= i+1; j<array.length-k;j++)
			{
				if(array[j]==array[i])
				{
					
					 while (j < (array.length) - 1) 
                     {
                         array[j] = array[j + 1];
                         j++;
                     }   
					total =total-1;
				}
				
			}
		}
	System.out.println(total);
		for(int i =0; i<total;i++)
		{
			System.out.println(array[i]);
		}
		
	}

}
