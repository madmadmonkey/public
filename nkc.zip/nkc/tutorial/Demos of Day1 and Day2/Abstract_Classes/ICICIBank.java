package Abstract_Classes;

public class ICICIBank extends GeneralBank{

	private double savingsAcc;
	private double fixedAcc;
	
	@Override
	public void getSavingInterestRate() {
		System.out.println("ICICI: Saving rate is 4%.");
		
	}

	@Override
	public void getFixedInterestRate() {
		System.out.println("ICICI: Fixed rate is 12.4%.");
	}
	public void nonAbstractMethod()
	{
		System.out.println("Hii, I am a concrete method");
	}
}
