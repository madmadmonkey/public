package Abstract_Classes;

public class KotMBank extends GeneralBank{

	@Override
	public void getSavingInterestRate() {
		System.out.println("Kotak: Saving rate is 6%.");
		
	}

	@Override
	public void getFixedInterestRate() {
		System.out.println("Kotak: Fixed rate is 9%.");
		
	}

}
