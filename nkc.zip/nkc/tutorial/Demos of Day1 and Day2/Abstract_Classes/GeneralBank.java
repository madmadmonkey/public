package Abstract_Classes;

public abstract class GeneralBank {
	public abstract void getSavingInterestRate();

	public abstract void getFixedInterestRate();
	public void nonAbstractMethod()
	{
		System.out.println("Hii, I am a concrete method");
	}

}
