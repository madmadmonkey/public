package Abstract_Classes;

import Package1.*;
import test_pack.*;


public class TestBank  {

	public static void main(String[] args) {
		
		GeneralBank[] gb= new GeneralBank[10];
		
		
	

		for(int i=0;i<gb.length;i++)
		{
		int  j =(int) ((Math.random()*10)%2) + 1;
		
		
		switch(j)
		{
		
		case 1: gb[i]= new ICICIBank();
						System.out.println(" Icici object created");
						gb[i].getFixedInterestRate();
						
		case 2:  gb[i]= new KotMBank();
					System.out.println(" Kotak object created");
					gb[i].getFixedInterestRate();
		
		
		}
			
			
		}
//		GeneralBank b=null;
//		ICICIBank i=new ICICIBank();
//		KotMBank k=new KotMBank();
//		i.getSavingInterestRate();
//		i.getFixedInterestRate();
//		i.nonAbstractMethod();
//		k.getSavingInterestRate();
//		k.getFixedInterestRate();
//		k.nonAbstractMethod();
//	b=i;
//	
//		Abc obj=new Abc();
//		Abc2 ob=new Abc2();
//		Test_Package tp=new Test_Package();
//	
////		b.getSavingInterestRate();
////		b.getFixedInterestRate();
////		b=k;
////		b.getSavingInterestRate();
////		b.getFixedInterestRate();
	}

}
