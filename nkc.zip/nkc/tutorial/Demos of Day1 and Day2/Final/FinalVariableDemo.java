package Final;

public class FinalVariableDemo {
	final int pi ;
	public FinalVariableDemo()
	{
		pi=2;
		
	}
	
	public FinalVariableDemo(int pi)
	{
		this.pi=pi;
	}
	public static void main(String[] args) {
		
			FinalVariableDemo g= new FinalVariableDemo();
		System.out.println(g.pi);
		
	}

}
