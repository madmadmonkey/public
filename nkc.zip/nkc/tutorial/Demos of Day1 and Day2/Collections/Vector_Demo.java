package Collections;

import java.util.*; 
public class Vector_Demo {
    public static void main(String []args) {
    	 
        Vector vector = new Vector(); //Declaring a Vector in Java
        
        vector.add(111);
        vector.add(222);
        vector.add(333);
        vector.add(444);
        vector.add(555);
        vector.add("HELLO");

        //Displaying vector elements
        System.out.println("The Integer Vector elements are:");
        System.out.println("");
        
        for (Object currVectorElement : vector) {
                 System.out.println(currVectorElement);
              }
 }     

}
