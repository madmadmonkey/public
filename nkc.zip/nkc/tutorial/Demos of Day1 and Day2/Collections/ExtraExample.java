package Collections;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class ExtraExample {
	public static void main(String[] args) {
		List list1 = new LinkedList();
		
		list1.add(0,"element 0");
		list1.add(1,"slement 1");
		list1.add(0,"zlement 2");
		System.out.println(list1.get(1));
		System.out.println(list1);
		Set set1 = new HashSet();
		set1.add(1);
		set1.add(45);
		set1.retainAll(list1);
		//boolean result =setB.containsAll(setA);
		System.out.println(set1);
	

//		ListIterator it1 = list.listIterator();
		
//		while (it1.hasNext()) {
//			String str=(String)it1.next();
//	
//			System.out.println("Next element: " + str);
//			
//		}
//		
//		while(it1.hasPrevious()){
//			System.out.println(it1.previous());
//		}

	}

}
