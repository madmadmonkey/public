package Collections;

public class Employee {
String Name;
int id;
float salary;

public void getDetails()
{
	System.out.println("name:" + Name + " id"  + id + "salary "+ salary);
}

}
