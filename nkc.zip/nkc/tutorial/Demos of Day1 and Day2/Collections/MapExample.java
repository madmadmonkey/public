package Collections;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class MapExample {
	
	public MapExample() {
		// TODO Auto-generated constructor stub
	}
	public static void main(String args[])
	{
		Map<Integer,String> mapA = new HashMap<Integer,String>();

		mapA.put(1, "element 1");
		mapA.put(2, "element 2");
		mapA.put(3, "element 3");
		mapA.put(2,"element 4");
		System.out.println(mapA);
		
		System.out.println("Fetching values using Iterator");
		Set s = mapA.keySet();
		Iterator iterator = s.iterator();
		while(iterator.hasNext()){
		  int key   =(int) iterator.next();
		  String value =(String)  mapA.get(key);
		  System.out.println(key);
		  System.out.println(value);
		}

		
		
		
//		
//		System.out.println("\nFetching values using for each loop");
//		//access via new for-loop
//		Set s1=mapA.keySet();
//		for(Object key : s1) {
//		    Object value = mapA.get(key);
//		    System.out.println(key);
//		    System.out.println(value);
//		}
//		
//		
//		
//		
//		
		System.out.println("\nFetching values using EntrySet");
		Set a = mapA.entrySet();
		Iterator entries = a.iterator();
		while (entries.hasNext()) {
		  Map.Entry thisEntry = (Map.Entry) entries.next();
		 int key = (int)thisEntry.getKey();
		  String value = (String)thisEntry.getValue();
		  System.out.println(key);
		  System.out.println(value);
		}
	}

}
