package Collections;

import java.util.Iterator;
import java.util.TreeSet;

public class StudentSetDemo {

	public static void main(String[] args) {
		TreeSet<Student> studentSet = new TreeSet<Student>();
		Student stud1 = new Student(1019,"Suresh");
		Student stud2 = new Student(1013,"Zainab");
		Student stud3 = new Student(1019,"Abhishek");
		studentSet.add(stud1);
		studentSet.add(stud2);
		studentSet.add(stud3);
		Iterator it = studentSet.iterator();
		
		while(it.hasNext()){
			
			Student s= (Student)it.next();
			System.out.println(s.rNo);
			System.out.println(s.sName);
		}
		
		
	}
}
