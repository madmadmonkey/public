package Collections;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class SetExample {

	public SetExample() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List set = new ArrayList();
		
		set.add(0,"one");
		set.add(1,"two");
		set.add(1,1);
		System.out.println(set.get(1));
		System.out.println(set.get(2));
		
		
		Iterator  i = set.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
		

		
//
		

//		//access via Iterator
//		Iterator iterator = setA.iterator();
//		while(iterator.hasNext()){
//		  String element = (String) iterator.next();
//		  System.out.println(element);
//		}


//		//access via new for-loop
//		for(Object object : setA) {
//		    String element = (String) object;
//		    System.out.println(element);
//		}

	}

}
