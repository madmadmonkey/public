package Collections;

import java.util.Iterator;
import java.util.Vector;

public class EmployeeDemo {

	public static void main(String[] args) {
		Vector<Employee>  vEmp= new Vector<Employee>();
		Employee e1 = new Employee();
		Employee e2 =  new Employee();
		e1.Name="SURBHI";
		e1.id= 1234;
		e1.salary = 500000;
		
		e2.Name = " abc";
		e2.id=9087;
		e2.salary= 7899;
		
		vEmp.add(e1);
		vEmp.add(e2);
		
		EmployeeDemo d = new EmployeeDemo();
		d.displayAll(vEmp);
	}
	
	public void displayAll(Vector v)
	{
		Employee[] e2=new Employee[v.size()];
		Employee e1[];
	    e1 = (Employee[]) v.toArray(e2);
	    e2[0]=null;
		for(int i=0;i<e2.length;i++){
			System.out.println("here" + e2[i]);
			System.out.println("here e1" +  e1[i]);
		}
		Iterator i = v.iterator();
		
		while(i.hasNext())
		{
			Employee e= (Employee)i.next();
			System.out.println(e.Name+ "has salary  "+ e.salary);
		}
	}
}
