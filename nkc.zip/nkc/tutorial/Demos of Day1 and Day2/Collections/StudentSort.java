package Collections;

import java.util.Set;
import java.util.TreeSet;

public class StudentSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<Student> s=new TreeSet<Student>();
		s.add(new Student(1,"alpha"));
		s.add(new Student(2,"seta"));
		s.add(new Student(3,"beta"));
		s.add(new Student(0,"gamma"));
		
		for(Object st:s){
			Student stud = (Student)st;
			System.out.println(stud.sName + "  roll no   " + stud.rNo);
	
		}
		
	}

}
