package Collections;

import java.util.Iterator;
import java.util.ListIterator;
import java.util.Set;
import java.util.TreeSet;

public class IteratorExample {
	public static void main(String args[]) {

		Set set = new TreeSet();
		set.add("One");
		set.add("Two");
		set.add("Three");
		set.add("Four");
		set.add("Five");
		
		Iterator i = set.iterator();
		
		while(i.hasNext()){
			
			System.out.println(i.next());
		}
		
//		System.out.println("Iterator using while loop: ");
//		ListIterator it = set.listIterator();
//		
//		
//		while(it.hasNext()){
//			String result = (String) it.next();
//			
//			System.out.println(result);
//			
//		}
//		while(it.hasPrevious())
//		{
//			System.out.println(it.previous());
//		}
//		
		
		
//		
//		for(Iterator it1 = set.iterator(); it.hasNext();){
//			String str= (String)it1.next();
//			
//			
//			System.out.println(str);
//			
//		}
//		
		
		
		
		
		
		
//		for( Object str: set){
//			int result = (int)str;
//			System.out.println(str);
//		}
//		
//		
		
//		System.out.println("List iterator (forward iteration): ");
//		ListIterator lit = list.listIterator();
//		while (lit.hasNext()) {
//			System.out.println("Next element: " + lit.next());
//
//		}
//		
//		while(lit.hasPrevious())
//		{
//			System.out.println("prev element" + lit.previous());
//		}
//
//     	System.out.println("List iterator (backward iteration): ");
//		ListIterator lit1 = list.listIterator(list.size());
//		while (lit1.hasPrevious()) {
//			System.out.println("Previous element: " + lit.previous());
//

//
	}

	}
