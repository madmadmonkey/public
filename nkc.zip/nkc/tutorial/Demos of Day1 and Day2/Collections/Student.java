package Collections;

public class Student implements Comparable {
	int rNo;
	String sName;
	Student(int rNo,String sName)
	{
		this.rNo=rNo;
		this.sName=sName;
	}
	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		Student stud = (Student)o;
		if(this.rNo<stud.rNo){
			return -1;
			
			
		}
		
		else if(this.rNo==stud.rNo) {
			
			return 0;
		}
		else
			return 1;
	}
	
}
	

