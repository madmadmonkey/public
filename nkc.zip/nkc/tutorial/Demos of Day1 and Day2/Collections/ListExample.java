package Collections;

import java.util.TreeSet;

public class ListExample {

	public ListExample() {
		// TODO Auto-generated constructor stub
	}
	
	public static void main(String[] args)
	{
//		HashSet setA = new HashSet();
//
//		setA.add("element 1");
//		setA.add("element 2");
//		setA.add("element 3");
//		setA.add(1);
//		setA.add(1);
//		setA.add("hello, I am at third pos");
//		setA.add(new ListExample());
//		
//		System.out.println(setA);
//		
//		
//		HashSet s= new HashSet();
//		s.add(1);
//		s.add("element 1");
//		listA.removeAll(s);
//		System.out.println(listA);

		TreeSet setA = new TreeSet();
		TreeSet setB= new TreeSet();
		
		setA.add(4);
		setA.add(1);
		setA.add(10);
		setA.add(6);
		setA.add(9);
		setA.add(2);
		setB.add(89);
		setB.add(101);
		System.out.println(setA.addAll(setB));
		System.out.println(setA);
		
		
		
//		ListIterator i = listA.listIterator();
//		System.out.println(i.previousIndex() + "      "+  i.nextIndex());
	}

}
