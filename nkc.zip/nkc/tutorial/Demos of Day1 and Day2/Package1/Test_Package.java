package Package1;

import static java.lang.Math.random;
import static java.lang.Math.pow;
import  static Package2.Person.age;

class Test_Package  {

	public Test_Package() {
		// TODO Auto-generated constructor stub
	}
	void ma1()
	{
	}
	public static void main(String args[])
	{
		System.out.println(age);
		double d=random();
	double d1=	pow(2,3);

		

	}

}
