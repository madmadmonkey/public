package multilevel_inheritance;

public class Inherit_person
{
	String name;
	String id;
	public Inherit_person(String name)
	{
		System.out.println("Inherit_person constructor begins");
		this.name=name;
		System.out.println("Inherit_person constructor ends");
	}
}