package multilevel_inheritance;

public class Inherit_collegeStudent extends Inherit_student
{
	private int year;
	private String major;
	public Inherit_collegeStudent(String name, String rollNo, int year, String major)
	{
		super(name,rollNo);
		System.out.println("Inherit_collegestudent constructor begins");
		this.year=year;
		this.major=major;
		System.out.println("Inherit_collegestudent constructor ends");
	}
	public void displayCollegeStudent()
	{
		System.out.println("Student Name: "+super.name);
		System.out.println("Student Roll No.: "+super.rollNo);
		System.out.println("Student Year: "+year);
		System.out.println("Student Major: "+major);
	}
	
	public static void main(String arr[])
	{
		String name="Trainer";
		String rollNo="101";
		int year=2014;
		String major="CSE";
		Inherit_collegeStudent c= new Inherit_collegeStudent(name,rollNo,year,major);
		c.displayCollegeStudent();
	}
}
