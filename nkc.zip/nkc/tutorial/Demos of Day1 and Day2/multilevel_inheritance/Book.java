package multilevel_inheritance;

public class Book {
	String name;
	double price;
	int qInStock;
	Author author;
	public String getName() {
		return name;
	}

	public Book(String name, double price, int qInStock, Author author) {
	
		this.name = name;
		this.price = price;
		this.qInStock = qInStock;
		this.author = author;
	}

	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getqInStock() {
		return qInStock;
	}
	public void setqInStock(int qInStock) {
		this.qInStock = qInStock;
	}
	public Author getAuthor() {
		return author;
	}

	public static void main(String[] args) {
		
		
	
Book book1= new Book("Java", 1000.00d,2, new Author("Surbhi", "abc@gmail.com", 'f') );
	
	String aName= book1.getAuthor().getName();
	
	System.out.println(aName);
	
	}

}
