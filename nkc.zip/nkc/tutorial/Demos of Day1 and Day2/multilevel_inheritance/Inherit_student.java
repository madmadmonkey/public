package multilevel_inheritance;

public class Inherit_student extends Inherit_person
{
	String rollNo;
	int empID;
	public Inherit_student(String name, String rollNo)
	{
		super(name);
		System.out.println("Inherit_student constructor begins");
		this.rollNo=rollNo;
		System.out.println("Inherit_student constructor ends");
		
	}
	
	public Inherit_student(String name, String rollNo, int empID)
	{
	
		this(name,rollNo);
		this.empID=empID;
		
		
	}
	
	
	void display()
	{
		System.out.println("name  "+ name+ "rollNo   "+ rollNo);
	}
	
	public static void main(String args[])
	{
		Inherit_student s1=new Inherit_student("hii", "101",1111);
		s1.display();
		
	}
}
