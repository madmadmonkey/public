package multilevel_inheritance;

public class Inherit_teacher extends Inherit_person
{
	private double salary;
	private String subject;
	public Inherit_teacher(String name, double salary, String subject)
	{
		super(name);
		this.salary=salary;
		this.subject=subject;
	}
	public void displayTeacher()
	{
		System.out.println("Teacher name: "+name);
		System.out.println("Teacher's salary: "+salary);
		System.out.println("Teacher's subject: "+subject);
	}
	
	public static void main(String arr[])
	{
		String name=arr[0];
		double salary=Double.parseDouble(arr[1]);
		String subject=arr[2];
		Inherit_teacher t=new Inherit_teacher(name,salary,subject);
		t.displayTeacher();
	}
}