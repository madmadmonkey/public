package static_example;

public class Stock_Static {

	public static int count=0;
	private String name;
	private String symbol;
	private double past;
	private double present;
	public Stock_Static(String name, String symbol, double past, double present)
	{
		this.name=name;
		this.symbol=symbol;
		this.present=present;
		this.past=past;
      
	}
	
	public static void display()
	{
		System.out.println("hii..I can be called without creating an object");
	}
	
	public  void displayWithoutStatic()
	{
		System.out.println("hii..I can be called creating an object");
	}
//	static {
//		System.out.println("I dont require any object");
//	}

	public static void main(String arr[])
	{
		String name="Zooka";
		String symbol="$$$$";
		double past=50.0;
		double present=60.0;
		
		Stock_Static s1=new Stock_Static(name, symbol, past, present);
		name="Zooka1";
		symbol="$$$$";
		past=60.0;
		present=70.0;
		Stock_Static s2=new Stock_Static(name, symbol, past, present);
		System.out.println("count for s1:		"+Stock_Static.count);
		System.out.println("count for s2:		"+Stock_Static.count);
		s1.count=80;
		System.out.println("count for s1:		"+Stock_Static.count);
		System.out.println("count for s2:		"+Stock_Static.count);
		s2.count=45;
		
		System.out.println("count for s1:		"+Stock_Static.count);
		System.out.println("count for s2:		"+Stock_Static.count);
		
		s1.displayWithoutStatic();
		display();
		
		
	}
//	static {
//		display();
//		System.out.println("I am second static block");
//	}
//	static {
//		System.out.println("I am second static block");
//	}
}