package Arrays;

class MultiDimArrayDemo {
	
    public static void main(String[] args) {
        String[][] names = {
            {"Mr. ", "Mrs. ", "Ms. "},
            {"Smith", "Jones"}
        };
        
        String names2[][] = new String[2][];
//        names2[0]= new String[3];
//        names2[1]= new String[2];
        names2[0][0]="Mr.";
        names2[0][1]="Mrs.";
        names2[0][2]="Ms.";
        names2[1][0]="Smith";
        names2[1][1]="Jones";
        
        for( int i = 0;i<names2.length; i++) {
        	
        	
        	for( int j=0; j<names2[i].length; j++) {
        		System.out.println("name is " + names2[i][j]);
        		
        	}
        }
        
        
        // Mr. Smith
        System.out.println(names[0][0] + names[1][0]);
        // Ms. Jones
        System.out.println(names[0][2] + names[1][1]);
        
        
    }
}
