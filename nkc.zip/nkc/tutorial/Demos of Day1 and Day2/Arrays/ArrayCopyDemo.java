package Arrays;

class ArrayCopyDemo {
    public static void main(String[] args) {
    	  int[] copyFrom = { 10,20,30,40,50,60,70 };
          int[] copyTo= new int[6];

          System.arraycopy(copyFrom, 1, copyTo, 2, 3);
          for(int i =0 ;i<copyTo.length;i++)
          {
          System.out.println(copyTo[i]);
          }
          
        char[] copyFrom1 = { 'd', 'e', 'c', 'a', 'f', 'f', 'e',
			    'i', 'n', 'a', 't', 'e', 'd' };
        char[] copyTo1 = new char[7];

        System.arraycopy(copyFrom1, 2, copyTo1, 0, 7);
        System.out.println(new String(copyTo1));
        
      
    }
}
