package Arrays;

public class Arrays {
public static void main(String[] args) {
	// declares an array of integers
	int[] anArray;
	
	// create an array of integers
	anArray = new int[10];
	
	anArray[0] = 100; // initialize first element
	anArray[1] = 200; // initialize second element
	anArray[2] = 300; // and so forth
	byte[] anArrayOfBytes;
	short[] anArrayOfShorts;
	long[] anArrayOfLongs;
	float[] anArrayOfFloats;
	double[] anArrayOfDoubles;
	boolean[] anArrayOfBooleans;
	char[] anArrayOfChars;
	String[] anArrayOfStrings;
	
	System.out.println("Element 1 at index 0: " + anArray[0]);
	System.out.println("Element 2 at index 1: " + anArray[1]);
	System.out.println("Element 3 at index 2: " + anArray[2]);
	
	int[] anArray1   = { 
		    100, 200, 300,
		    400, 500, 600, 
		    700, 800, 900, 1000
		};
	
	for(int i: anArray1){
		System.out.println(i);
	}
	System.out.println("length of array1:    "+ anArray1.length);
	 
	
}
}
