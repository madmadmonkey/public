package OverLoading;

class Overload
{
	public void array(int a[])
	{
		System.out.println("Integer array is:");
		for(int i=0;i<a.length;i++)
			System.out.println(a[i]);
	}
	public void array(double b[])
	{
		System.out.println("Double array is:");
		for(int i=0;i<b.length;i++)
			System.out.println(b[i]);
	}
	public void array(char c[])
	{
		System.out.println("Character array is:");
		for(int i=0;i<c.length;i++)
			System.out.println(c[i]);
	}
}