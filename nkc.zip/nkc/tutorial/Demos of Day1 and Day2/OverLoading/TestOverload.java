package OverLoading;

public class TestOverload
{
public static void main(String arr[])
{
	int a[]={10,20,30,40,50};
	double b[]={10.1,20.1,30.1,40.1,50.1};
	char c[]={'a','b','c','d','e'};
	Overload o=new Overload();
	o.array(a);
	o.array(b);
	o.array(c);
}
}