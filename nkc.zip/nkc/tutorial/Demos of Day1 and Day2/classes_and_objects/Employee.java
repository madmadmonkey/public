package classes_and_objects;

public class Employee {
	
	private int empId;
	String empName;
	float empSalary;
	
	public void setempId(int empId) {
		this.empId= empId;
	}
	Employee()
	{
		empId=101;
		empName="undefined";
		empSalary=1000f;
		
		System.out.println("zero argument const");
	}
	
	Employee(String name) 
	{
		this();
		this.empName= empName;
		
		
		System.out.println("in one arg const");
	}
	
	Employee(int empId, String empName) {
		
		this(empName);
		this.empId=empId;
		
	
		System.out.println("in two arg const");
	}
	
	Employee(int empId, String empName, float empSalary) {
		
		this(empId,empName);
		this.empSalary = empSalary;
		System.out.println("in three arg const");
	}
	
	public void getDetails()
	{
		System.out.println("Emp name "+ empName+ "emp id " + empId +"Emp salary   " + empSalary);
	}
	
	public static void main(String[] args) {
		
//		//second case
//		Employee emp = new Employee();
//		emp.getDetails();
//		emp.empId=60;
		Employee emp2 = new Employee(102, "Surbhi",3000);
		emp2.getDetails();
		
		
		
		
		
		
		
		
		
		
		
		
		
		//first example
//		emp.empId = 101;
//		emp.empName= "Amalu";
//		
//	emp.empSalary= 50000;

	
	
//	emp2.empId = 102;
//	emp2.empName= "Sharath";
//	
//emp2.empSalary= 50000;

		
	}
}
