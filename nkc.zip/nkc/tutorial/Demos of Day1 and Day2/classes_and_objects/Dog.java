package classes_and_objects;

//Class Declaration

public class Dog
{
 // Instance Variables
 String name;
 String breed;
 int age;
 String color;
 
 public Dog()
 {
	 name= "no name";
	 breed = "undefined";
	 age= -1 ;
	 color = " not defined";
 }
// overloaded Constructor Declaration of Class
 public Dog(String name1, String breed1,
                int age1, String color1)
 {
   name = name1;
     breed = breed1;
     age = age1;
     color = color1;
 }

 //Setter methods

 public void setName(String name) {
	this.name = name;
}
public void setBreed(String breed) {
	this.breed = breed;
}
public void setAge(int age) {
	this.age = age;
}
public void setColor(String color) {
	this.color = color;
}

 // method 1
 public String getName()
 {
     return name;
 }

 // method 2
 public String getBreed()
 {
     return breed;
 }

 // method 3
 public int getAge()
 {
     return age;
 }

 // method 4
 public String getColor()
 {
     return color;
 }

// @Override
// public String toString()
// {
//     return("Hi my name is "+ this.getName()+
//            ".\nMy breed,age and color are " +
//            this.getBreed()+"," + this.getAge()+
//            ","+ this.getColor());
// }

 public static void main(String[] args)
 {
   Employee emp= new Employee();
   emp.setempId(40);
 }
}