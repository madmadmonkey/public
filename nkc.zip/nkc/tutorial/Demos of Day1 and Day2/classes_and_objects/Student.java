package classes_and_objects;

public class Student {
	
	int studId;
	String studName;
	 int admNo;
	 static int studCount;
		
	static
	{
		System.out.println("in static block 1");
	}
	
	
	public void getDetails() {
		System.out.println("name "+ studName + "student id " + studId+ "student admsn no "+ admNo);
	}
	
	
	
	public static String displayStudentCount(){
		System.out.println("in static method displayAdmNo");
		return "admsn no is " + studCount;
	}
	
	static{
		System.out.println("in static block 2");
	}
	
	public static void main(String[] args) {
		Student s1= new Student();
		s1.studId= 101;
		s1.studName="Surbhi";
		s1.admNo=111;		
		s1.studCount++;
		s1.getDetails();
		s1.displayStudentCount();
		
		Student s2= new Student();
		s2.studId= 102;
		s2.studName="Swati";
		s2.admNo=103;
		s2.studCount++;
		s2.getDetails();
		s2.displayStudentCount();
		
		s1.displayStudentCount();
		
		
		


	}
	
	static{
		
		System.out.println("in static block 3");
	}

}
