package com.wipro.util;

public class InvalidAgeException extends Exception{
	//Method 1 to convey the error message
	//Override the toString method
	
/*	public String toString()
	{
		return "Invalid Age";
	}*/
	
	//Method 2 to convey the error message
	//pass the message to super class constructor
	public InvalidAgeException(){
		super("Invalid Age");
	}
	public InvalidAgeException(String message){
		super(message);
	}
}
