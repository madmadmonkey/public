package com.wipro.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Tester {
public static void main(String[] args) {
	int var11=Integer.parseInt(args[0]);
	int var21=Integer.parseInt(args[1]);
	int res1 = var11/var21;
	try{
		int var1=Integer.parseInt(args[0]);
		int var2=Integer.parseInt(args[1]);
		int res = var1/var2;
		System.out.println(res);
	}
	catch(ArithmeticException e){
		System.out.println("Please enter non zero values");		
	}
	catch(NumberFormatException e){
		System.out.println("Please enter only numbers");
	}
	catch(Exception e){
	 System.out.println("Exception occured :: "+e);
	 e.printStackTrace();
	}finally{
		System.out.println("Program Terminated");
	}
	System.out.println("Job Done");
}
}
