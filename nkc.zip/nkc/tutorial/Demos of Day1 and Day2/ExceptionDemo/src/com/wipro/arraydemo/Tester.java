package com.wipro.arraydemo;

import com.wipro.bean.Employee;

public class Tester {
public static void main(String[] args) {
	int arr[] = new int[3];
	arr[2]=10;
	Employee emps[] = new Employee[3];
	emps[0] = new Employee();
	emps[1] = new Employee(12,"RAM",23);
	emps[0].setEmployeeID(11);
	emps[0].setEmployeeName("Seetha");
	Employee obj = new Employee();
	
}
}
