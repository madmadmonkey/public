package com.wipro.bean;

public class Tester {
public static void main(String[] args) {
	Employee o = new Employee();
	try {
		o.setAge(11);
	} catch (Exception e) {
		e.printStackTrace();
	}
	System.out.println("Program Terminated");
}
}
