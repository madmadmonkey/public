package com.wipro.test;

import java.util.ArrayList;
import java.util.Iterator;

public class CollectionDemo {
public static void main(String[] args) {
	ArrayList a = new ArrayList();
	a.add("a");
	a.add("b");
	a.add("c");
	a.add("d");
	
	Iterator it = a.iterator();
	System.out.println("First:: "+it.next());
	System.out.println("Second:: "+it.next());
	while(it.hasNext()){
		char x = it.next().toString().charAt(0);
		System.out.println(x);
		if (x=='b')
			it.remove();				
	}
	System.out.println(a);
	
}
}
