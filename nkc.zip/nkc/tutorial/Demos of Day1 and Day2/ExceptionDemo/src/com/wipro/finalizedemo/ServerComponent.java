package com.wipro.finalizedemo;

public class ServerComponent {
	public static void main(String[] args) {
		for(int i=0;i<3;i++){
			Request req = new Request("Message "+(i+1));
		}
		Runtime.getRuntime().gc();
		System.out.println("Job Done");
		System.out.println("No of live objects ::"
				+Request.liveRequestCount);
	}
}
