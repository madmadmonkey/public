package com.wipro.finalizedemo;

public class Request {
public static int liveRequestCount=0;
public String requestMessage;
public String getRequestMessage() {
	return requestMessage;
}
public void setRequestMessage(String requestMessage) {
	this.requestMessage = requestMessage;
}
private Request() {
	liveRequestCount++;
	System.out.println("Cons:: no of live objects : "+liveRequestCount);
}

public Request(String requestMessage) {
	this();
	this.requestMessage = requestMessage;
}
public void finalize(){
	liveRequestCount--;
	System.out.println("Finalize:: no of live objects : "+liveRequestCount);
}

}
