package String;

public class Difference
{
public static void main(String args[])
{
	StringBuffer s1=new StringBuffer("wipro");
	s1.append("Technologies");
	s1.replace(0, 5, "Infosys");
	System.out.println(s1);
	}
}