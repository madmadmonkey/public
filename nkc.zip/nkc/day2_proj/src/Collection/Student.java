package Collection;

public class Student implements Comparable{
	
	int rNo;
	String sName;
	
		public Student(int rNo, String sName) {
		super();
		this.rNo = rNo;
		this.sName = sName;
	}

		public int compareTo(Object o) 
		{
			Student stud=(Student)o;
			if(this.rNo<stud.rNo)
			return -1;
			else if(this.rNo==stud.rNo)
				return 0;
			else
				return 1;
		}
		
		
		
		
	}


