package Collection;
import java.util.TreeSet;
import java.util.Iterator;
public class treeSet 
{
	public static void main(String[] args) {
		/*TreeSet<Integer> tree=new TreeSet<Integer>();
		/*tree.add("alpha");
		tree.add("gamma");
		tree.add("beta");
		tree.add("Alpha");
		tree.add(1);*/
		TreeSet<Student> stu=new TreeSet<Student>();
		Student stu1=new Student(5, "nkc");
		Student stu2=new Student(3, "nil");
		Student stu3=new Student(6, "nkc");
		stu.add(stu1);
		stu.add(stu2);
		stu.add(stu3);
		Iterator<Student> it=stu.iterator();
		while(it.hasNext())
		{
			Student s=it.next();
			System.out.println(s.rNo);
			System.out.println(s.sName);
		}
	}
}
