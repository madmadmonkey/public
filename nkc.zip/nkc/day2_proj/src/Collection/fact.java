package Collection;

public class fact {

	public static void main(String[] args) {
		int num,fact=1;
		num=Integer.parseInt(args[0]);
		for(int term=1;term<=num;term++)
			fact=fact*term;
		System.out.println("factorial = "+fact);

	}

}
