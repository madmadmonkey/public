package Collection;

import java.util.ArrayList;
import java.util.ListIterator;

public class ArrayListDemo 
{

	public static void main(String[] args) 
	{
		ArrayList arrayList=new ArrayList();
		arrayList.add(1);
		arrayList.add("one");
		arrayList.add(4.56f);
		System.out.println(arrayList);
		arrayList.add(2,"two");
		
System.out.println(arrayList);
ListIterator it=arrayList.listIterator(2);
while(it.hasNext())
{
	System.out.println(it.next());
}
	}

}
