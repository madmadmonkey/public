package Collection;

public class UniqueDigits 
{
	public static void main(String[] args) 
	{
		int arr[]=new int[10];
		int num=Integer.parseInt(args[0]);
		int i=0,count=0;
		if(num>=1 && num<=250000){
		while(num>0)
		{
			arr[i++]=num%10;
			num=num/10;
		}
		for(int j=0;j<i-1;j++)
		{
			for(int k=j+1;k<i;k++)
			{
				if(arr[j]==arr[k] && arr[k]>=0)
				{
					count+=2;
					arr[k]=-1;
				}
			}
		}
		count--;
		i--;
		System.out.println("Unique digits = "+(i-count));
		}
		
		
	}

}
