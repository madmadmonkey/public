package Collection;

public class Fibo {

	public static void main(String[] args) {
		int num,prev=1,curr=0,next;
		num=Integer.parseInt(args[0]);
		for(int step=1;step<=num;step++)
		{
			System.out.print(curr+" ");
		next=prev+curr;
		curr=prev;
		prev=next;
		}
	}

}
