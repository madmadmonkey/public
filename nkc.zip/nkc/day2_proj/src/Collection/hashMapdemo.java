package Collection;
import java.util.HashMap;
import java.util.Set;
import java.util.Iterator;
import java.util.Map;

public class hashMapdemo {
	public static void main(String[] args) {
		/*HashMap<String,Integer> map=new HashMap<String,Integer>();
		map.put("nkc",1);
		map.put("nil",2);
		int i=map.get("nkc");
		System.out.println(i);
		Set s=map.keySet();
		Iterator it=s.iterator();
		while(it.hasNext())
		{
			String key=(String)it.next();
			int value=map.get(key);
			System.out.println(key + " " + value);
		}
		HashMap<Integer,Integer> map=new HashMap<Integer,Integer>();
		map.put(10,1);
		map.put(10,2);
		int i=map.get(10);
		System.out.println(i);
		Set s=map.keySet();
		Iterator it=s.iterator();
		while(it.hasNext())
		{
			Integer key=(Integer)it.next();
			int value=map.get(key);
			System.out.println(key + " " + value);
		}*/
		HashMap<Integer,String> map=new HashMap<Integer,String>();
		map.put(1,"nkc");
		map.put(2,"nil");
		String i=map.get(1);
		System.out.println(i);
		Set s=map.keySet();
		Iterator it=s.iterator();
		while(it.hasNext())
		{
			Integer key=(Integer)it.next();
			String value=map.get(key);
			System.out.println(key + " " + value);
		}
		Set s2=map.entrySet();
		Iterator it2=s2.iterator();
		while(it2.hasNext())
		{
			Map.Entry e=(Map.Entry)it2.next();
			Integer key=(Integer)e.getKey();
			String value=(String)e.getValue();
			System.out.println(key + " " + value);
		}
	}

}
