package day1_proj1;

public class Excep
{
	public static void main(String[] args)  
	{
		try
		{
		int var1=10;
		int var2=20;
		int res=var1/var2;
		System.out.println(res);
		}
		catch(ArithmeticException e)
		{
			System.out.println("nkc");
		}
		catch(NumberFormatException e)
		{
			System.out.println("nil");
		}
		catch(Exception e)
		{
			System.out.println("index   "+e);
		}
		
		finally 
		{
			System.out.println("final");
		}
		System.out.println("ok");
}
}
