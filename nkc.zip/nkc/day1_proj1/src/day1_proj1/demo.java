package day1_proj1;

public class demo {

	public static void main(String[] args) 
	{
		int[] arr=new int[5];
		   arr[0]=Integer.parseInt(args[0]);
		   arr[1]=Integer.parseInt(args[1]);
		   arr[2]=Integer.parseInt(args[2]);
		   arr[3]=Integer.parseInt(args[3]);
		   arr[4]=Integer.parseInt(args[4]);
		   int[] stable=new int[5];
			int[] unstable=new int[5];
			int i,j=0,k=0;
			for(i=0;i<5;i++)
			{
				if(isStable(arr[i]))
					stable[j++]=arr[i];
				else
				{
					unstable[k++]=arr[i];
					System.out.print("unstable number="+unstable[k-1]);}
			}
			//return(max(stable)-min(unstable));
			System.out.println(max(stable)-min(unstable));
			System.out.println("stable="+max(stable));
			System.out.println("unstable="+min(unstable));
		}
		static int max(int[] st)
		{
			int mx=0;
			for(int i=0;i<5;i++)
			{
				if(mx<st[i])
					mx=st[i];
			}
			return mx;
		}
		static int min(int[] st)
		{
			int mx=st[0];
			for(int i=1;i<5;i++)
			{
				if(mx>st[i]&&st[i]!=0)
					mx=st[i];
			}
			System.out.println("minimum="+mx);
			return mx;
		}
	public static boolean isStable(int no)
	{
		int[] arr=new int[10];
		int i=0,flag=-1;
		while(no>0)
		{
			arr[no%10]++;
			no=no/10;
		}
		System.out.println();
		for(i=0;i<10;i++)
		{
			
			System.out.print("   num= "+arr[i]);
			if(arr[i]==0)
				continue;
			if(flag==-1)
			{
				flag=arr[i];
				continue;
			}
			if(flag!=arr[i])
			{
				return false;
			}
		}
		
		return true;
	}
	}