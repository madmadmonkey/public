package day1_proj1;

public class metl {

	public static void main(String[] args) 
	{
		String input1="HELLO WORLD"; 
		String[] array1= input1.split(" ");
		String con="";
		
		   int sum1=0,i=0;
			while(i<array1.length)
			{
				sum1=find(array1[i++]);
				  System.out.println("result="+con);
				con=con.concat(Integer.toString(sum1));
				  
			}
				
   System.out.println("result="+con);
	}
static int find(String inp1)
{
	int res=0,i=0,j,n1,n2,no;
	j=inp1.length()-1;
	String inp=inp1.toUpperCase();
	while(i<j)
	{
		n1=inp.charAt(i);
		n2=inp.charAt(j);
		res=res+Math.abs((n1-64)-(n2-64));
		i++;
		j--;
	}
	if((inp1.length())%2!=0)
	{
		char c=inp1.charAt((inp1.length())/2);
		no=c;
		res=Math.abs(res+(no-64));
	}
	return res;
}
}
