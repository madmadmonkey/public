package day1_proj1;

public abstract class Figure {
	public abstract int area();
	public abstract float perimeter();

}
