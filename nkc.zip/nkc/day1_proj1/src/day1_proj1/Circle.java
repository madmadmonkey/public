package day1_proj1;

public class Circle extends Figure {
	int radius;
	
	public int area()
	{
		return (int)(3.14*radius*radius);
	}
	public float perimeter()
	{
		return (float)(2*3.14*radius);
	}
	public static void main(String[] args) {
		Circle circle=new Circle();
		circle.radius=20;
		int area=circle.area();
		System.out.println(area);
		
	}

}
