package day1_proj1;

public class start {

	public static void main(String[] args) {
		int dgsum,num,sum,div;
		num=Integer.parseInt(args[0]);
		do
		{
			sum=0;
			while(num>0)
			{
				div=num%10;
				num=num/10;
				sum=sum+div;
			}
			dgsum=sum;
			num=sum;
		}while(sum>9);
		System.out.println(dgsum);	
	}

}
