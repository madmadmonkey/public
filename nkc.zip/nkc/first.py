print 'hello'
print 'nilkamal'
