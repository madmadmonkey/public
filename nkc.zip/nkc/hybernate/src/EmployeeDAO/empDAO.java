package EmployeeDAO;




import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


import empClass.Employee;


public class empDAO 
{
	public static void main(String[] args) 
	{
		empDAO dao=new empDAO();
		dao.addEmployee();
		/*Employee em=dao.getEmployee(10);
		System.out.println("Employee Number = "+em.getEmpNo()+"Employee Name = "+em.getEmpName()+"Employee Gender = "+em.getEmpGender()+"Employee Date of Joining = "+em.getEmpDoj()+"Employee Salary = "+em.getEmpSalary());*/
	}
	
	public void addEmployee()
	{
		Configuration cfg=new Configuration();
		SessionFactory sf=cfg.configure().buildSessionFactory();
		Session session=sf.openSession();
		Transaction transaction=session.beginTransaction();
		
		Employee e=new Employee();
		//e.setEmpNo(10);
		e.setEmpName("nkc");
		e.setEmpGender('M');
		e.setEmpDoj(new java.util.Date());
		e.setEmpSalary(15650.50);
		session.save(e);
		 transaction.commit();
		 session.close();		
	}
	public Employee getEmployee(int eNo)
	{
		Configuration cfg=new Configuration();
		SessionFactory sf=cfg.configure().buildSessionFactory();
		Session session=sf.openSession();
		Transaction transaction=session.beginTransaction();
		
		Employee e=(Employee)session.get(empClass.Employee.class, eNo);
		session.close();
		return e;
		
	}

}
