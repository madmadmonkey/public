package com.wipro.book.service;

import com.wipro.book.bean.AuthorBean;
import com.wipro.book.bean.BookBean;
import com.wipro.book.dao.BookDAO;


public class Administrator {
	public String addBook(BookBean bookBean) {
		// write code here
		
		
		String ret="";
		AuthorBean author=new AuthorBean();
		BookDAO bDAO=new BookDAO();
		if(bookBean==null)
			return "INVALID";	
		author=bookBean.getAuthor();
				
		if(bookBean.getBookName().length()==0)
			return "INVALID";
		if(bookBean.getIsbn().length()==0)
			return "INVALID";
		if(bookBean.getBookType()==' ')
			return "INVALID";
		if(bookBean.getBookType()!='G' && bookBean.getBookType()!='T')
			return "INVALID";
		if(bookBean.getCost()==0)
			return "INVALID";
		if(author.getAuthorName().length()==0)
			return "INVALID";
		int result=bDAO.createBook(bookBean);
		if(result==1)
			ret="SUCCESS";
		else
			ret="FAILURE";

		return ret;
	}

	public BookBean viewBook(String isbn) {
	
		BookBean bookBean=null;
		BookDAO bdao=new BookDAO();
		if(isbn==null)
			return null;
		if(isbn.length()==0)
			return null;
		bookBean=bdao.fetchBook(isbn);
		if(bookBean==null)
			return null;
		
		return bookBean;
		
	}

}
