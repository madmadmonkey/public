package com.wipro.book.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wipro.book.bean.AuthorBean;
import com.wipro.book.bean.BookBean;
import com.wipro.book.service.Administrator;


/**
 * Servlet implementation class MainServlet
 */
public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public MainServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO write code here
		String oPr=request.getParameter("operation");
		String sbn=request.getParameter("ISBN");
		String rEt;
		BookBean bookBean=null;
		ServletContext sc=getServletContext();
		if(oPr.equalsIgnoreCase("AddBooks")==true)
		{
			rEt=addBook(request);
			if(rEt.equalsIgnoreCase("SUCCESS")==true)
			{
				RequestDispatcher rd=sc.getRequestDispatcher("/Menu.html");
				rd.forward(request, response);
			}
			if(rEt.equalsIgnoreCase("FAILURE")==true)
			{
				RequestDispatcher rd=sc.getRequestDispatcher("/Failure.html");
				rd.forward(request, response);
			}
			if(rEt.equalsIgnoreCase("INVALID")==true)
			{
				RequestDispatcher rd=sc.getRequestDispatcher("/Invalid.html");
				rd.forward(request, response);
			}
		}
		if(oPr.equalsIgnoreCase("Search")==true)
		{
			bookBean=viewBook(sbn);
			if(bookBean==null)
			{
				RequestDispatcher rd=sc.getRequestDispatcher("/Invalid.html");
				rd.forward(request, response);
			}
			else
			{
				RequestDispatcher rd=sc.getRequestDispatcher("/View.jsp");
				rd.forward(request, response);
			}
		}
	}

	public BookBean viewBook(String isbn) {
		Administrator administrator = new Administrator();
		BookBean mybean = administrator.viewBook(isbn);
		// write code here
		return mybean;
	}

	public String addBook(HttpServletRequest request) {
		String result = "";
		
		BookBean bookBean=new BookBean();
		AuthorBean ath=new AuthorBean();
		Administrator adm=new Administrator();
		String isb=request.getParameter("ISBN");
		String athname=request.getParameter("Author_Name");
		String bname=request.getParameter("Bookr_Name");
		String btype=request.getParameter("Bookr_Type");
		String cost=request.getParameter("Book_Cost");
		char bt=btype.charAt(0);
		Float cst=Float.parseFloat(cost);
		ath.setAuthorName(athname);
		bookBean.setAuthor(ath);
		bookBean.setBookName(bname);
		bookBean.setBookType(bt);
		bookBean.setCost(cst);
		bookBean.setIsbn(isb);
		result=adm.addBook(bookBean);
		return result;

	}

}
