package com.wipro.book.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.wipro.book.bean.AuthorBean;
import com.wipro.book.bean.BookBean;
import com.wipro.book.util.DBUtil;

public class BookDAO {
	public int createBook(BookBean bookBean) {
		int count = 0;
		AuthorBean author = bookBean.getAuthor();
		Connection con=DBUtil.getDBConnection();
		try
		{
			PreparedStatement psInsert=con.prepareStatement("insert into Book_Tbl values(?,?,?,?,?)");
			psInsert.setString(1,bookBean.getIsbn());
			psInsert.setString(2,bookBean.getBookName());
			psInsert.setString(3,String.valueOf(bookBean.getBookType()));
			psInsert.setInt(4,author.getAuthorCode());
			psInsert.setFloat(5,bookBean.getCost());
			int result=psInsert.executeUpdate();
			if(result==1)
				count=1;
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			count=0;
		}
		
		
		return count;
	}

	public BookBean fetchBook(String isbn) {
		BookBean mybean = new BookBean();
		AuthorBean author = new AuthorBean();
		AuthorDAO aDao=new AuthorDAO();
		ResultSet rs;
		int acode;
		Connection con=DBUtil.getDBConnection();
		try
		{
			String qry="select * from Book_Tbl where ISBN='"+isbn+"'";
			Statement st=con.createStatement();
			rs=st.executeQuery(qry);
			if(rs.next())
			{
				acode=rs.getInt("Author_Code");
				author=aDao.getAuthor(acode);
				mybean.setAuthor(author);
				mybean.setBookName(rs.getString("Book_title"));
				mybean.setBookType(rs.getString("Book_type").charAt(0));
				mybean.setCost(rs.getFloat("Book_cost"));
				//mybean.setIsbn(rs.getString("ISBN"));
				mybean.setIsbn(isbn);
				return mybean;
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return null;
	}

}
