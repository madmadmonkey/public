package com.wipro.book.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.wipro.book.bean.AuthorBean;
import com.wipro.book.util.DBUtil;

public class AuthorDAO {
	AuthorBean getAuthor(int authorCode) {
		AuthorBean author = new AuthorBean();
		ResultSet rs;
		Connection con=DBUtil.getDBConnection();
		try
		{
			String qry="select * from Author_Tbl where Author_code="+authorCode;
			Statement st=con.createStatement();
			rs=st.executeQuery(qry);
			if(rs.next())
			{
				author.setAuthorCode(rs.getInt("Author_Code"));
				author.setAuthorName(rs.getString("Author_name"));
				author.setContactNo(rs.getLong("Contact_no"));
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return author;
	}

	AuthorBean getAuthor(String authorName) {
		AuthorBean author =new AuthorBean();
		
		ResultSet rs;
		Connection con=DBUtil.getDBConnection();
		try
		{
			String qry="select * from Author_Tbl where Author_name='"+authorName+"'";
			Statement st=con.createStatement();
			rs=st.executeQuery(qry);
			if(rs.next())
			{
				author.setAuthorCode(rs.getInt("Author_Code"));
				author.setAuthorName(rs.getString("Author_name"));
				author.setContactNo(rs.getLong("Contact_no"));
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return author;
	}
}
