package com.mile1.bean;

public class Student {
	
	public Student()
	{
		
	}
	
	public String name;
	public int marks[]=new int[3];
	
	public Student(String name, int[] marks) {
		setName(name);
		setMarks(marks);
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int[] getMarks() {
		return marks;
	}
	public void setMarks(int[] marks) {
		this.marks = marks;
	}
	

}
