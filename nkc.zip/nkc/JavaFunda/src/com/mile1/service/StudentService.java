package com.mile1.service;

import com.mile1.bean.*;

public class StudentService 
{
	public int findNumberOfNullMarks(Student data[])
	{
		int numberMarks=0;
		int size=data.length;
		for(int i=0;i<size;i++)
		{
			if(data[i]!=null && data[i].getMarks()==null)
				numberMarks++;
		}
		return numberMarks;
	}
	
	public int findNumberOfNullNames(Student data[])
	{
		int numberName=0;
		int size=data.length;
		for(int i=0;i<size;i++)
		{
			if(data[i]!=null && data[i].getName()==null)
				numberName++;
		}
		return numberName;
	}
	
	public int findNumberOfNullObjects(Student data[])
	{
		int numberObj=0;
		int size=data.length;
		
		for(int i=0;i<size;i++)
		{
			if(data[i]==null)
				numberObj++;
		}
		return numberObj;
	}

}
