package com.mile1.service;

import com.mile1.bean.*;
import com.mile1.exception.*;

public class StudentReport 
{
	public String findGrade(Student studentObject)
	{
		int sum=0,flag=0;
		for(int i=0;i<3;i++)
		{
			if(studentObject.marks[i]<35)
			{
				flag=1;
				break;
			}
			else
				sum+=studentObject.marks[i];				
		}
		if(flag==1)
			return "F";
		else
		{
			if(sum>250 && sum<=300)
				return "A";
			else if(sum>200 && sum<=250)
				return "B";
			else if(sum>150 && sum<=200)
				return "C";
			else
				return "D";
		}
	}
	
	public String validate(Student studentObject) throws NullNameException,NullMarksArrayException, NullStudentException
	{
		if(studentObject==null)
			throw new NullStudentException();
		if(studentObject.getName()==null)
			throw new NullNameException();
		if(studentObject.getMarks()==null)
			throw new NullMarksArrayException();
		return(findGrade(studentObject));
	}

}
