package JsPackage;

public class Candidate 
{
	private int canID;
	private String candName;
	private String course;
	
	public Candidate() {
		super();
	}

	
	
	public int getcanID() {
		return canID;
	}
	public void setcanID(int canID) {
		this.canID = canID;
	}
	public String getcandName() {
		return candName;
	}
	public void setcandName(String candName1) {
		candName = candName1;
	}
	public String getcourse() {
		return course;
	}
	public void setcourse(String course1) {
		course = course1;
	}	
}


