package com.wipro.controller;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ApplicationController 
{
	@RequestMapping("start")
	public String doStart()
	{
		return "homepage";
	}

}
