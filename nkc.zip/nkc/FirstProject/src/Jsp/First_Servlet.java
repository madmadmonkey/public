package Jsp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class First_Servlet
 */
@WebServlet("/First_Servlet")
public class First_Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public First_Servlet() {
        super();
        System.out.println("FROM CONSTRUCTOR.....");
        // TODO Auto-generated constructor stub
    }
    
    public void init()
    {
    	System.out.println("FROM INIT");
    }
    
    public void destroy()
    {
    	System.out.println("FROM destroy");
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter out=response.getWriter();
		out.println("HELLO WORLD");
		System.out.println("FROM DO-GET METHOD");
		response.setContentType("text/html");
		out.println("<html>");
		out.println("<head>");
		out.println("<title>Request Object Example</title>");
		out.println("</head>");
		out.println("<body bgcolor=red ><font color=\"blue\" >");
		out.println("<h1>"+"Request object info :"+"</h1>"+"<br>");
		out.println("<b>Method :</b>"+request.getMethod()+"<br>");
		out.println("<b>Request URI :</b>"+request.getRequestURI()+"<br>");
		out.println("<b>Protocol :</b>"+request.getProtocol()+"<br>");
		out.println("<b>Pathinfo :</b>"+request.getPathInfo()+"<br>");
		out.println("<b>Remote Address :</b>"+request.getRemoteAddr()+"<br>");
		out.println("</font></body>");
		out.println("</html>");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
