
public class mock {

	public static void main(String[] args) {
		int input1=Integer.parseInt(args[0]);
		int input2=Integer.parseInt(args[1]);
		int input3=Integer.parseInt(args[2]);
		int input4=Integer.parseInt(args[3]);
		int input5=Integer.parseInt(args[4]);
		int result=fun(input1,input2,input3,input4,input5);
		System.out.println(result);

	}
public static int fun(int input1,int input2,int input3,int input4,int input5)
{
	int out=0;
	int[] item=new int[5];
	item[0]=input1;
	item[1]=input2;
	item[2]=input3;
	item[3]=input4;
	item[4]=input5;
	int[] stable=new int[5];
	int[] unstable=new int[5];
	int i,search,s=0,u=0;
	for(i=0;i<5;i++)
	{
		search=check(item[i]);
		if(search==1)
			stable[s++]=item[i];
		if(search==0)
			unstable[u++]=item[i];
	}
	for(i=0;i<s;i++)
	{
		for(int j=0;j<s-1;j++)
		{
			if(stable[j]<stable[j+1])
			{
				int temp=stable[j];
				stable[j]=stable[j+1];
				stable[j+1]=temp;
			}
		}
	}
	for(i=0;i<u;i++)
	{
		for(int k=0;k<u-1;k++)
		{
			if(unstable[k]>unstable[k+1])
			{
				int temp1=unstable[k];
				unstable[k]=unstable[k+1];
				unstable[k+1]=temp1;
			}
		}
	}
out=stable[0]-unstable[0];
return out;
}
static int check(int num) 
{
	int[] arr=new int[10];
	int i=0;
	int no,ret;
	while(i<10)
	{
		arr[i++]=0;
	}
	while(num>0)
	{
		no=num%10;
		arr[no]=arr[no]+1;
		num=num/10;
	}
	int sum=0;
	for(i=0;i<10;i++)
		sum=sum+arr[i];
	if(sum%2==0)
		ret=1;
	else
		ret=0;
	return ret;
}
}
