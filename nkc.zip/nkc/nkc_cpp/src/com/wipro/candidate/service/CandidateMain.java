package com.wipro.candidate.service;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


import com.wipro.candidate.bean.CandidateBean;
import com.wipro.candidate.dao.CandidateDAO;
import com.wipro.candidate.util.DBUtil;
import com.wipro.candidate.util.WrongDataException;


public class CandidateMain {

	/**
	 * @param args
	 */
	public String addCandidate(CandidateBean studBean)
	{
		String result="";
		String ret="";
		CandidateDAO can=new CandidateDAO();
		try
		{
		if(studBean==null)
			throw new WrongDataException();
		if(studBean.getName().length()==0)
			throw new WrongDataException();
		if(studBean.getName().length()<=2)
			throw new WrongDataException();
		if((studBean.getM1()<0) && (studBean.getM1()>100))
			throw new WrongDataException();
		if((studBean.getM2()<0) && (studBean.getM2()>100))
			throw new WrongDataException();
		if((studBean.getM3()<0) && (studBean.getM3()>100))
			throw new WrongDataException();
		studBean.setId(can.generateCandidateId(studBean.getName()));
		int tmark=studBean.getM1()+studBean.getM2()+studBean.getM3();
		if(tmark<105)
		{
			studBean.setResult("FAIL");
			studBean.setGrade("No Grade");
		}
		else if(tmark>=105 && tmark<150)
		{
			studBean.setResult("PASS");
			studBean.setGrade("Third Class");
		}
		else if(tmark>=150 && tmark<180)
		{
			studBean.setResult("PASS");
			studBean.setGrade("Second Class");
		}
		else if(tmark>=180 && tmark<240)
		{
			studBean.setResult("PASS");
			studBean.setGrade("First Class");
		}
		else
		{
			studBean.setResult("PASS");
			studBean.setGrade("Distinction");
		}
		ret=can.addCandidate(studBean);
		if(result.equals("SUCCESS")==true)
			result=studBean.getId()+":PASS";
		else
			result="Error";
		}
		catch(WrongDataException e)
		{
			return e.toString();
		}


		
	    return result;
		
	}
	public ArrayList<CandidateBean> displayAll(String criteria)
	{
		ArrayList<CandidateBean> list=new ArrayList<CandidateBean>();
		list=null;
		CandidateDAO can=new CandidateDAO();
		try
		{
			if(criteria.equalsIgnoreCase("PASS")==true||criteria.equalsIgnoreCase("FAIL")==true||criteria.equalsIgnoreCase("ALL")==true)
			{
				list=can.getByResult(criteria);
			
			}
			else
				throw new WrongDataException();			
		}
		catch(WrongDataException e)
		{
			return null;
		}
		
		return list;
		
	}
	public static void main(String[] args) {
		
		/*CandidateMain candidateMain = new CandidateMain();

		String result = candidateMain.addCandidate(null);

		System.out.println(result);
		
	*/}

}
