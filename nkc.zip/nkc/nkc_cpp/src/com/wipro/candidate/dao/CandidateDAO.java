package com.wipro.candidate.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.wipro.candidate.bean.CandidateBean;
import com.wipro.candidate.util.DBUtil;


public class CandidateDAO {
	public String addCandidate(CandidateBean studentBean)
	{
			String status="FAIL";
			//write code here
			Connection con=DBUtil.getDBConn();
			try
			{
				PreparedStatement psInsert=con.prepareStatement("insert into CANDIDATE_TBL values(?,?,?,?,?,?,?)");
				psInsert.setString(1,studentBean.getId());
				psInsert.setString(2,studentBean.getName());
				psInsert.setInt(3,studentBean.getM1());
				psInsert.setInt(4,studentBean.getM2());
				psInsert.setInt(5,studentBean.getM3());
				psInsert.setString(6,studentBean.getResult());
				psInsert.setString(7,studentBean.getGrade());
				int result=psInsert.executeUpdate();
				if(result==1)
					status="SUCCESS";
			}
			catch(SQLException e)
			{
				e.printStackTrace();
				status="FAIL";
			}
				return status;
	}
	public ArrayList<CandidateBean> getByResult(String criteria)
	{
		ArrayList<CandidateBean> list=new ArrayList<CandidateBean>();
		CandidateBean canBean=new CandidateBean();
		ResultSet rs;
		Connection con=DBUtil.getDBConn();
		try
		{
			String qry=null;
			Statement st=con.createStatement();
			if(criteria.equalsIgnoreCase("pass")==true)
			{
				qry="select * from dept where Result='PASS'";
				//rs=st.executeQuery(qry);
			}
			else if(criteria.equalsIgnoreCase("fail")==true)
			{
				qry="select * from dept where Result='FAIL'";
				//rs=st.executeQuery(qry);
			}	
			if(criteria.equalsIgnoreCase("all")==true)
			{
				qry="select * from dept";
				//rs=st.executeQuery(qry);
			}
			else
				list=null;
			rs=st.executeQuery(qry);
			while(rs.next())
			{
				canBean.setGrade(rs.getString("Grade"));
				canBean.setId(rs.getString("ID"));
				canBean.setM1(rs.getInt("M1"));
				canBean.setM2(rs.getInt("M2"));
				canBean.setM3(rs.getInt("M3"));
				canBean.setName(rs.getString("Name"));
				canBean.setResult(rs.getString("Result"));
				list.add(canBean);
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		return list;
	}
	public String generateCandidateId (String name)
	{
		String id="";
		//write code here
		String str=name.toUpperCase().substring(0, 2);
		String qry="select CANDID_SEQ.nextval from dual";
		Connection con=DBUtil.getDBConn();
		int num=0;
		try
		{
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery(qry);
			if(rs.next())
			{
				num=rs.getInt(1);
				
			}
			id=str.concat(Integer.toString(num));
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return id;
	}
}
