package java_IO;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Serializ 
{
	public static void main(String[] args) 
	{
		//Object store to text file
		/*StuSerial stu=new StuSerial();
		stu.setEngMarks(80);
		stu.setGrade('A');
		stu.setMathMarks(70);
		stu.setrNo(40);
		stu.setsName("nil");
		try
		{
			FileOutputStream fOut=new FileOutputStream("D://Regular//nkc//object//object.txt");
			ObjectOutputStream oOs=new ObjectOutputStream(fOut);
			oOs.writeObject(stu);
			System.out.println("SUCCESS");
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}*/
		//Object retrieve from text file
		/*StuSerial stu1=new StuSerial();
		try
		{
			FileInputStream fin=new FileInputStream("D://Regular//nkc//object//object.txt");
			ObjectInputStream obIn=new ObjectInputStream(fin);
			stu1=(StuSerial)obIn.readObject();
			System.out.println(stu1);
			System.out.println("Successfuly retrieve");
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}*/

		
	}

}
