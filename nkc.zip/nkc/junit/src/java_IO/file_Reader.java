package java_IO;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
public class file_Reader {
	public static void main(String[] args) {
		try
		{
			FileReader fr=new FileReader("D:\\Regular\\nkc\\java_io.txt");
			BufferedReader br=new BufferedReader(fr);
			char[] str=new char[100];
			int i=0;
			char ch;
			//while((i=fr.read())!=-1)//for read character by character
			while((i=br.read(str))!=-1)
			{
				//char ch=(char)i;//for read character by character
				System.out.println(str);
			}
			fr.close();
			System.out.println("End of Reading");
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		
	}

}
