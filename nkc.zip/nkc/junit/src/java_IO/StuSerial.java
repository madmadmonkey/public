package java_IO;

import java.io.Serializable;

public class StuSerial implements Serializable
{
	static int rNo;
	String sName;
	char grade;
	transient int engMarks;
	int mathMarks;
	public int getrNo() {
		return rNo;
	}
	public void setrNo(int rNo) {
		this.rNo = rNo;
	}
	public String getsName() {
		return sName;
	}
	public void setsName(String sName) {
		this.sName = sName;
	}
	public char getGrade() {
		return grade;
	}
	public void setGrade(char grade) {
		this.grade = grade;
	}
	public int getEngMarks() {
		return engMarks;
	}
	public void setEngMarks(int engMarks) {
		this.engMarks = engMarks;
	}
	public int getMathMarks() {
		return mathMarks;
	}
	public void setMathMarks(int mathMarks) {
		this.mathMarks = mathMarks;
	}
	
	public String toString()
	{
		return ("Name= "+getsName()+"Roll No = "+getrNo() + "English Marks = "+getEngMarks()+" Math Marks = "+getMathMarks() + " Grade = "+getGrade());
	}

}
