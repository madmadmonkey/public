package JuNit;

public class Arith 
{
	public int a;
	public int b;
	public int add(){return (a+b);}
	public int sub(){return Math.abs(a+b);}

}
