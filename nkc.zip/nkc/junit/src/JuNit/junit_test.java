package JuNit;

import static org.junit.Assert.*;

import org.junit.Ignore;
import org.junit.Test;

//@Ignore ({"add"},{"sub"})
public class junit_test {

	@Ignore
	@Test
	public void add() {
		Arith obj=new Arith();
		obj.a=5;
		obj.b=6;
		int exp=12;
		assertEquals("addition failed",exp,obj.add());
	}
	
	@Ignore
	@Test
	public void sub() {
		Arith obj=new Arith();
		obj.a=5;
		obj.b=6;
		int exp=11;
		assertEquals("subtraction failed",exp,obj.sub());
	}
	
	@Test
	public void same() {
		String a="Hello";
		String b="Hello";
		assertSame(a,b);
		
	}

}
