package spring.bean;

public class Address 
{
	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Address(String streeName, String city) {
		super();
		this.streeName = streeName;
		this.city = city;
	}
	String streeName;
	String city;
	public String getStreeName() {
		return streeName;
	}
	public void setStreeName(String streeName) {
		this.streeName = streeName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Override
	public String toString() {
		return "Address [streeName=" + streeName + ", city=" + city + "]";
	}
	
	

}
