package spring.bean;

public class Employee 
{
	
	int EmpID;
	String eName;
	private Address address;
	
	
	
	
	
	public Employee(int empID, String eName, Address address) {
		super();
		this.EmpID = empID;
		this.eName = eName;
		this.address = address;
	}
	public int getEmpID() {
		return EmpID;
	}
	public void setEmpID(int empID) {
		EmpID = empID;
	}
	public String geteName() {
		return eName;
	}
	
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public void seteName(String eName) {
		this.eName = eName;
	}
	@Override
	public String toString() {
		return "Employee [EmpID=" + EmpID + ", eName=" + eName + ", address=" + address + "]";
	}
	public Employee(int empID, String eName) {
		super();
		EmpID = empID;
		this.eName = eName;
	}
	
	
	

}
