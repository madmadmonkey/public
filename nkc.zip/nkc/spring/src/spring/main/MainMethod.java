package spring.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import spring.bean.Employee;

public class MainMethod {

	public static void main(String[] args) {
		/*
		 //old method
		 
		Employee obj=new Employee();
		obj.setEmpID(101);
		obj.seteName("NKC");
		System.out.println(obj);
*/
		// using spring
		ApplicationContext ac=new ClassPathXmlApplicationContext("config.xml");
		Employee obj=(Employee) ac.getBean("employeeObj");
		System.out.println(obj);
	}

}
