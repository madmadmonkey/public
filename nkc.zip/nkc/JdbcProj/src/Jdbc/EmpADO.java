package Jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class EmpADO 
{
	Connection con=null;
	PreparedStatement psInsert=null;

	public EmpADO() throws SQLException 
	{
		con=new DBConnection().getConnection();
		psInsert=con.prepareStatement("insert into emp_test values(?,?,?)");	
	}
	public String insEmp(dateExm obj)
	{
		try
		{
			psInsert.setInt(1, obj.getEmpNo());
			psInsert.setString(2, obj.getEmpName());
			java.sql.Date sqldate=new java.sql.Date(obj.getHireDate().getTime());
			psInsert.setDate(3, sqldate);
			int result=psInsert.executeUpdate();
			if(result==1)
				return "SUCCESS";
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return "FAIL";
	}
	
}
