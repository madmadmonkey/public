package Jdbc;

import java.util.Date;

public class dateExm 
{
public dateExm(int empNo, String empName, Date hireDate) {
		this.empNo = empNo;
		this.empName = empName;
		this.hireDate = hireDate;
	}
int empNo;
String empName;
Date hireDate;



public Date getHireDate() {
	return hireDate;
}
public void setHireDate(Date hireDate) {
	this.hireDate = hireDate;
}
public int getEmpNo() {
	return empNo;
}
public void setEmpNo(int empNo) {
	this.empNo = empNo;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}


}
