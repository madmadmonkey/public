package Jdbc;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

public class CalStmt 
{
	CallableStatement cSt=null;
	Connection con=null;	


public CalStmt() throws SQLException
{
	con=new DBConnection().getConnection();
	cSt=con.prepareCall("call updDept(?,?)");
}

public String UpdDept(int dn, String lo)
{
	try
	{
		cSt.setInt(2, dn);
		cSt.setString(1, lo);
		int result=cSt.executeUpdate();
		System.out.println("RESULT" + result);
		return "SUCCESS";
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	return "FAIL";
}
}