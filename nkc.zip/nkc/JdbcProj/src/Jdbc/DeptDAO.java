package Jdbc;

import java.sql.Statement;
import java.util.ArrayList;

import java.sql.Connection;
import java.sql.ResultSet;

public class DeptDAO
{
	public String InsertDept(Department obj)
	{
		try
		{
			DBConnection o=new DBConnection();
			Connection con=o.getConnection();
			Statement stmt=con.createStatement();
			//insert direct value 
			//	String qry="insert into dept values(50,'NKC','KOL')";
			//insert value from object 
			String qry="insert into dept values("+obj.getDeptNo()+",'"+obj.getdName()+"','"+obj.getLoc()+"')";
			int result=stmt.executeUpdate(qry);
			if(result==1)
				return "SUCCESS";
			else
				return "FAIL";
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return "FAIL";
	}
	public Department getData(int deptno)
	{
		Department dpt=null;
		try
		{
			DBConnection o=new DBConnection();
			Connection con=o.getConnection();
			Statement st=con.createStatement();
			String qry="select * from dept where deptno="+deptno;
			ResultSet rs=st.executeQuery(qry);
			if(rs.next())
			{
				int dno=rs.getInt("deptno");
				String dn=rs.getString(2);
				String lc=rs.getString("loc");
				dpt=new Department(dno,dn,lc);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return dpt;
	}
	public ArrayList<Department> getDepartments()
	{
		ArrayList<Department> arList=new ArrayList<Department>();
		Department dpt=null;
		try
		{
			DBConnection o=new DBConnection();
			Connection con=o.getConnection();
			Statement st=con.createStatement();
			String qry="select * from dept";
			ResultSet rs=st.executeQuery(qry);
			while(rs.next())
			{
				int dno=rs.getInt("deptno");
				String dn=rs.getString(2);
				String lc=rs.getString("loc");
				dpt=new Department(dno,dn,lc);
				arList.add(dpt);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return arList;
	}
	
}
