package Jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class preStatement 
{
	Connection con=null;
	PreparedStatement psInsert=null;
	PreparedStatement psUpd=null;

	public preStatement() throws SQLException 
	{
		con=new DBConnection().getConnection();
		psInsert=con.prepareStatement("insert into dept values(?,?,?)");	
		psUpd=con.prepareStatement("update dept set loc=? where deptno=?");
	}
	
	public String InsDept(Department obj)
	{
		try
		{
			psInsert.setInt(1,obj.getDeptNo());
			psInsert.setString(2, obj.getdName());
			psInsert.setString(3, obj.getLoc());
			int result=psInsert.executeUpdate();
			if(result==1)
				return "SUCCESS";
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return "FAIL";
	}
	
	public String UpdDept(int dn, String lo)
	{
		try
		{
			psUpd.setInt(2, dn);
			psUpd.setString(1, lo);
			int result=psUpd.executeUpdate();
			if(result==1)
				return "SUCCESS";
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return "FAIL";
	}
	
}
