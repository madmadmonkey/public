package Jdbc;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ListIterator;
import java.util.Scanner;

public class JDBCMain 
{

	public static void main(String[] args) throws SQLException
	{
		//Testing Connection
		/*DBConnection dbcon=new DBConnection();
		dbcon.getConnection();*/
		Department obj=new Department(80,"NILKAMAL","SERAMPORE");
		DeptDAO dao=new DeptDAO();
		//Insert element
		/*String res=dao.InsertDept(obj);
		System.out.println(res);*/
		//Display a particular record
		/*obj=dao.getData(50);
		System.out.println(obj);*/
		//Display all record(s)
		//Insert element through object
		//String res=dao.InsertDept(obj);
		//Insert element through prepareStatement
		/*preStatement pSt=new preStatement();
		String res=pSt.InsDept(obj);*/
		//Update record using PreparedStatement
		/*Scanner sc=new Scanner(System.in);
		System.out.println("Enter department no. which location update");
		int no=sc.nextInt();
		System.out.println("Enter new location");
		String loca=sc.next();
		preStatement pSt=new preStatement();
		String res=pSt.UpdDept(no,loca);*/
		//Update record using PreparedStatement
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter department no. which location update");
		int no=sc.nextInt();
		System.out.println("Enter new location");
		String loca=sc.next();
		CalStmt calSt=new CalStmt();
		String res=calSt.UpdDept(no,loca);
		System.out.println(res);
		ArrayList<Department> arList1=new ArrayList<Department>();
		arList1=dao.getDepartments();
		ListIterator it=arList1.listIterator();
		while(it.hasNext())
			System.out.println(it.next());
	}
}
