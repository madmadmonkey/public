package Jdbc;

public class test {
	public static void main(String[] args) {
	@SuppressWarnings("unused")	
	int x=0;
	int y=1;
	
	
	}
}
