package Jdbc;

import java.sql.SQLException;
import java.util.Date;
import java.util.Scanner;

public class Emp 
{
	public static void main(String[] args) throws SQLException {
		int no;
		String sname;
		char[] n=new char[20];
		Date dt=new Date();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Employee no.");
		no=sc.nextInt();
		System.out.println("Enter Employee Name");
		sname=sc.next();
		dateExm emp=new dateExm(no,sname,dt);
		EmpADO empADO=new EmpADO();
		String res=empADO.insEmp(emp);
		System.out.println(res);
		
	
	}
	

}
