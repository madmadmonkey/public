package com.wipro.hms.util;

public class InvalidCityException extends Exception {

	
	public String toString() {
		
		return "INVALID CITY";
	}
}
