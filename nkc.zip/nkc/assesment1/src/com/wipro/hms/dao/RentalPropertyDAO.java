package com.wipro.hms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.wipro.hms.util.DBUtil;
import com.wipro.hms.bean.RentalPropertyBean;



public class RentalPropertyDAO {
	
	public String generatePropertyID(String city) {
		String id="";
		//write code here
		System.out.println(city);
		String str=city.toUpperCase().substring(0,3);
		String qry="select RENTAL_SEQ.nextval from dual";
		Connection con=DBUtil.getDBConnection();
		int num=0;
		try
		{
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery(qry);
			if(rs.next())
			{
				num=rs.getInt(1);
				
			}
			id=str.concat(Integer.toString(num));
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return id;
	}

	public int createRentalProperty(RentalPropertyBean bean) 
	{

		String retId="";
		int result;
		try
		{
		Connection con=DBUtil.getDBConnection();
		retId=generatePropertyID(bean.getCity());
		System.out.println("checked = "+retId);
		bean.setPropertyId(retId);
		
			PreparedStatement psInsert=con.prepareStatement("insert into RENTAL_TBL values(?,?,?,?,?)");
			psInsert.setString(1,bean.getPropertyId());
			psInsert.setFloat(2,bean.getRentalAmount());
			psInsert.setInt(3,bean.getNoOfBedRooms());
			psInsert.setString(4,bean.getLocation());
			psInsert.setString(5,bean.getCity());
			result=psInsert.executeUpdate();
			if(result>0)
				return result;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			result=-1;
		}
			return -1;
	}

	
}
