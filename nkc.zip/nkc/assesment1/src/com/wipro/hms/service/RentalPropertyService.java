package com.wipro.hms.service;




import com.wipro.hms.bean.RentalPropertyBean;
import com.wipro.hms.dao.RentalPropertyDAO;
import com.wipro.hms.util.InvalidCityException;

public class RentalPropertyService {
	public static void main(String[] args) {
		//Write your code here
	}

	public String addRentalProperty(RentalPropertyBean bean) {
		
		String ret="FAILURE";
		if(bean.getCity()==null )
			return "NULL VALUES IN INPUT";
		if(bean.getLocation()==null)
			return "NULL VALUES IN INPUT";
		if(bean.getCity().length()==0)
			return "INVALID INPUT";
		if(bean.getLocation().length()==0)
			return "INVALID INPUT";
		/*if( bean.getCity().length()<3)
			return "INVALID INPUT";*/

		if(bean.getNoOfBedRooms()==0 || bean.getRentalAmount()==0)
			return "INVALID INPUT";
		try
		{
			validateCity(bean.getCity());
		}
		catch(InvalidCityException e)
		{
			return "INVALID CITY";
		}
		try
		{
			RentalPropertyDAO renPro=new RentalPropertyDAO();
			int res=renPro.createRentalProperty(bean);
			if(res>0)
				ret="SUCCESS";
			else
				ret="FAILURE";
		}
		catch(Exception e)
		{
			return "FAILURE";
		}
		return ret;
	}

	
	public void validateCity(String city) throws InvalidCityException {
		
		if((city.equalsIgnoreCase("chennai")==true) || (city.equalsIgnoreCase("bengaluru")==true))
		{
			
		}
		else
			throw new InvalidCityException();
		
		
		
	}
}
