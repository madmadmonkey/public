package com.wipro.bean;

public class Employee {
	int EmpId;
	String Ename;
	Address address;
	
	
	public Address getAddress() {
		return address;
	}
	public Employee(int empId, String ename, Address address) {
		super();
		EmpId = empId;
		Ename = ename;
		this.address = address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public int getEmpId() {
		return EmpId;
	}
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(int empId, String ename) {
		super();
		EmpId = empId;
		Ename = ename;
	}
	public void setEmpId(int empId) {
		EmpId = empId;
	}
	@Override
	public String toString() {
		return "Employee [EmpId=" + EmpId + ", Ename=" + Ename + ", address=" + address + "]";
	}
	public String getEname() {
		return Ename;
	}
	public void setEname(String ename) {
		Ename = ename;
	}
}
