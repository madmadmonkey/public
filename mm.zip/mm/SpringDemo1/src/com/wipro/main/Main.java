package com.wipro.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.wipro.bean.Employee;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * Old Traditional Method
		 * Employee o=new Employee();
		o.setEmpId(101);
		o.setEname("MM");*/
		
		ApplicationContext ac=new ClassPathXmlApplicationContext("config.xml");
		Employee o=(Employee)ac.getBean("employee");
		System.out.println(o);
		
	}

}
