package com.wipro.candidate.service;

import java.util.ArrayList;


import com.wipro.candidate.bean.CandidateBean;
import com.wipro.candidate.dao.CandidateDAO;
import com.wipro.candidate.util.WrongDataException;


public class CandidateMain {

	/**
	 * @param args
	 * @throws WrongDataException 
	 */
	public String addCandidate(CandidateBean studBean) 
	{
		String result="";
	    //write code here
		result="ErroraddCmain";
		try{
			if(studBean==null)
				throw new WrongDataException();
			
			if(studBean.getName().length()==0||studBean.getName().length()<=2)
				throw new WrongDataException();
			
			if(studBean.getM1()<0||studBean.getM1()>100)
				throw new WrongDataException();
			if(studBean.getM2()<0||studBean.getM2()>100)
				throw new WrongDataException();
			if(studBean.getM3()<0||studBean.getM3()>100)
				throw new WrongDataException();
			
			CandidateDAO cDao=new CandidateDAO();
			
			studBean.setId(cDao.generateCandidateId(studBean.getName()));
			System.out.println(studBean.getId());
			int total=studBean.getM1()+studBean.getM2()+studBean.getM3();
			
			if(total>=180&&total<240){
				studBean.setResult("PASS");
				studBean.setGrade("First Class");
			}
			if(total>=150&&total<180){
				studBean.setResult("PASS");
				studBean.setGrade("Second Class");
			}
			if(total>=105&&total<150){
				studBean.setResult("PASS");
				studBean.setGrade("Third Class");
			}
			if(total>=240){
				studBean.setResult("PASS");
				studBean.setGrade("Distinction");
			}
			if(total<105){
				studBean.setResult("FAIL");
				studBean.setGrade("No Grade");
			}
				
				String msg=cDao.addCandidate(studBean);
				if(msg.equalsIgnoreCase("SUCCESS")){
					return studBean.getId()+":"+studBean.getResult();
				}
		
		}catch(WrongDataException e){
			return "Data Incorrect";
		}
		
		return result;
		
	}
	public ArrayList<CandidateBean> displayAll(String criteria)
	{
			
		//return null;
		
		//write code here
		ArrayList<CandidateBean> list=new ArrayList<CandidateBean>();
		try{
		if(criteria.equalsIgnoreCase("PASS") || criteria.equalsIgnoreCase("FAIL") ||criteria.equalsIgnoreCase("ALL")){
			CandidateDAO cDao=new CandidateDAO();
			list=cDao.getByResult(criteria);
		}
		else
			throw new WrongDataException();
		
		
		}
		catch(WrongDataException e){
			return null;
		}
		return list;
	}
	public static void main(String[] args) {
		//write code here
		/*CandidateMain candidateMain = new CandidateMain();

		String result = candidateMain.addCandidate(null);
		//CandidateDAO cdao=new CandidateDAO();
		//CandidateBean cb=new CandidateBean();
		

		System.out.println(cdao.generateCandidateId("manik"));*/
		//----------------------------------------------------------------------
		CandidateMain candidateMain = new CandidateMain();
		CandidateBean b=new CandidateBean();
		b.setM1(62);b.setM2(61);b.setM3(65);
		b.setName("abcd");
	
		String result = candidateMain.addCandidate(b);

		System.out.println(result);
	}

}
