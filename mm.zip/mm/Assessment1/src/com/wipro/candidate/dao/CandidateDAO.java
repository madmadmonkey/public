package com.wipro.candidate.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.wipro.candidate.bean.CandidateBean;
import com.wipro.candidate.util.DBUtil;


public class CandidateDAO {
	public String addCandidate(CandidateBean studentBean)
	{
			String status="";
			//write code here
			status="FAIL";
			try {
			Connection conn=DBUtil.getDBConn();
			
			String sql="insert into CANDIDATE_TBL values (?,?,?,?,?,?,?)";
			PreparedStatement pInsert=conn.prepareStatement(sql);
			pInsert.setString(1, studentBean.getId());
			pInsert.setString(2,studentBean.getName());
			pInsert.setInt(3, studentBean.getM1());
			pInsert.setInt(4, studentBean.getM2());
			pInsert.setInt(5, studentBean.getM3());
			pInsert.setString(6,studentBean.getResult());
			pInsert.setString(7,studentBean.getGrade());
			
			int r=pInsert.executeUpdate();
			if(r>0)
				return "SUCCESS";
			
				
			} catch (Exception e) {;
				// TODO Auto-generated catch block
				//e.printStackTrace();
			return "FAIL";
			}
			
			
			return status;
	}
	public ArrayList<CandidateBean> getByResult(String criteria)
	{
		ArrayList<CandidateBean> list=new ArrayList<CandidateBean>();
		//write code here
		PreparedStatement ps=null;
		ResultSet rs=null;
		try {
			Connection conn=DBUtil.getDBConn();
			
			String sql="select * from CANDIDATE_TBL where result=(?)";
			
			if(criteria.equalsIgnoreCase("PASS")){
				
				ps=conn.prepareStatement(sql);
				ps.setString(1, "PASS");
			}
			if(criteria.equalsIgnoreCase("FAIL")){
				
				ps=conn.prepareStatement(sql);
				ps.setString(1, "FAIL");
			}
			if(criteria.equalsIgnoreCase("ALL")){
				
				ps=conn.prepareStatement("select * from CANDIDATE_TBL");
			}
			rs=ps.executeQuery();
			if(rs==null)
				return null;
			while(rs.next()){
				CandidateBean c=new CandidateBean();
				c.setId(rs.getString(1));
				c.setName(rs.getString(2));
				c.setM1(rs.getInt(3));
				c.setM2(rs.getInt(4));
				c.setM3(rs.getInt(5));
				c.setGrade(rs.getString(7));
				c.setResult(rs.getString(6));
				list.add(c);
			}
				
		} catch (Exception e) {
			// TODO: handle exception
			return null;
		}
		return list;
	}
	public String generateCandidateId (String name)
	{
		String id="";
		//write code here
		String str=name.toUpperCase().substring(0, 2);
		//name=name.substring(0, 2);
		ResultSet rs=null;
		String sql="select candid_seq.nextval from dual";
		
		try {
			Connection conn=DBUtil.getDBConn();
			Statement stmt=conn.createStatement();
			rs=stmt.executeQuery(sql);
			if(rs.next())
				id=Integer.toString(rs.getInt(1));
			//System.out.println(id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		id=str.concat(id);
		System.out.println(id);
		return id;
	}
}
