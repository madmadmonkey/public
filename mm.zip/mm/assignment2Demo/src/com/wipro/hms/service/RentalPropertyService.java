package com.wipro.hms.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.wipro.hms.bean.RentalPropertyBean;
import com.wipro.hms.dao.RentalPropertyDAO;
import com.wipro.hms.util.InvalidCityException;

public class RentalPropertyService {
	public static void main(String[] args) throws SQLException, InvalidCityException {
		//Write your code here
		RentalPropertyBean bean=new RentalPropertyBean();
		bean.setCity("chennai");
		bean.setNoOfBedRooms(2);
		bean.setRentalAmount(1000);
		bean.setLocation("chennai");
		RentalPropertyDAO rdao=new RentalPropertyDAO();
		System.out.println(rdao.generatePropertyID(bean.getCity()));
		RentalPropertyService obj=new RentalPropertyService();
		obj.validateCity("chennai");
		System.out.println(bean.getCity().equalsIgnoreCase("chennai"));
		
	}

	public String addRentalProperty(RentalPropertyBean bean) {
		
		//Write your code here
		if(bean.getCity()==null||bean.getLocation()==null)
			return "NULL VALUES IN INPUT";
		
		if(bean.getCity().length()==0||bean.getLocation().length()==0)
			return "INVALID INPUT";
		
		if(bean.getNoOfBedRooms()==0||bean.getRentalAmount()==0)
			return "INVALID INPUT";
		//String cityValidate=
		try {
			validateCity(bean.getCity());
		} catch (InvalidCityException e) {
			// TODO: handle exception
			return "INVALID CITY";
		}
		try {
			RentalPropertyDAO rDao=new RentalPropertyDAO();
			int status=0;
			status=rDao.createRentalProperty(bean);
			if(status>0)
				return "SUCCESS";
			else
				return "FAILURE";
		} catch (Exception e) {
			// TODO: handle exception
			return "FAILURE";
		}	
		
		
		//return "FAILURE";
	}

	
	public void validateCity(String city) throws InvalidCityException {
		//Write your code here
		if(city.equalsIgnoreCase("chennai")==true||city.equalsIgnoreCase("bengaluru")==true){
			
		}
		else
			throw new InvalidCityException();
	}
}
