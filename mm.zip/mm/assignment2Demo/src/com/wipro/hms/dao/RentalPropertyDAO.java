package com.wipro.hms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.wipro.hms.util.DBUtil;
import com.wipro.hms.bean.RentalPropertyBean;



public class RentalPropertyDAO {
	public String generatePropertyID(String city) throws SQLException {
		String id = "";
		//Write your code here
		String strUpper=city.toUpperCase();
		String sub=strUpper.substring(0, 3);
		ResultSet rs=null;
		String sql="select Rental_seq.nextval from dual";
		Connection conn=null;
		Statement stmt=null;
		
		try {
			conn=DBUtil.getDBConnection();
			stmt=conn.createStatement();
			rs=stmt.executeQuery(sql);
			if(rs.next())
				id=Integer.toString(rs.getInt(1));
			//System.out.println(id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		conn.close();
		stmt.close();
		rs.close();
		id=new String(sub.concat(id));
		return id;
	}

	public int createRentalProperty(RentalPropertyBean bean) {

		//Write your code here
		try {
			bean.setPropertyId(generatePropertyID(bean.getCity()));
			Connection conn=DBUtil.getDBConnection();
			
			String sql="insert into RENTAL_TBL values (?,?,?,?,?)";
			PreparedStatement pInsert=conn.prepareStatement(sql);
			pInsert.setString(1, bean.getPropertyId());
			pInsert.setFloat(2,bean.getRentalAmount());
			pInsert.setInt(3, bean.getNoOfBedRooms());
			pInsert.setString(4, bean.getLocation());
			pInsert.setString(5, bean.getCity());
			
			
			int r=pInsert.executeUpdate();
			if(r>0)
				return r;
		} catch (Exception e) {
			// TODO: handle exception
			return -1;
		}
		
		return -1;
	}

	
}
