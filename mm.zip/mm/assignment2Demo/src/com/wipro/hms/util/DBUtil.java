package com.wipro.hms.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class DBUtil {
	

	public static Connection getDBConnection() {
		//Write your code here
		Connection conn=null;
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl",
					"B2018021903","B2018021903");
			//System.out.println("Conn :"+conn);
			
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		}
		catch (SQLException e) {
			
			e.printStackTrace();
		}
		return conn;
		//return null;
	}

}
