import com.wipro.book.bean.AuthorBean;
import com.wipro.book.bean.BookBean;
import com.wipro.book.service.Administrator;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BookBean book=new BookBean();
		AuthorBean author=new AuthorBean();
		book.setIsbn("Alc1234");
		book.setBookName("Alchemist");
		book.setBookType('G');
		book.setCost(266.50f);
		
		author.setAuthorName("Paulo Coelho");
		book.setAuthor(author);
		Administrator administrator = new Administrator();
		String result=administrator.addBook(book);
		System.out.println(result);
		System.out.println("done");
	}

}
