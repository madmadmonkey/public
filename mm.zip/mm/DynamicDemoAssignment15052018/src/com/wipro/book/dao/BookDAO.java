package com.wipro.book.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

//import com.wipro.book.bean.AuthorBean;
import com.wipro.book.bean.BookBean;
import com.wipro.book.util.DBUtil;

public class BookDAO {
	public int createBook(BookBean bookBean) {
		int count = 0;
		// write code here
		///ResultSet rs=null;
		Connection conn=null;
		PreparedStatement stmt=null;
		String sql="insert into book_tbl values(?,?,?,?,?)";
		try {
			
			conn=DBUtil.getDBConnection();
			stmt=conn.prepareStatement(sql);
			stmt.setString(1, bookBean.getIsbn());
			stmt.setString(2, bookBean.getBookName());
			stmt.setString(3, bookBean.getBookType()+"");
			stmt.setInt(4, bookBean.getAuthor().getAuthorCode());
			stmt.setFloat(5, bookBean.getCost());
			System.out.println(sql);
			//stmt.
			count=stmt.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
			return 0;
		}
		//////////if(count==1)return count;
		
		return count;
	}

	public BookBean fetchBook(String isbn) {
		BookBean mybean = null;
		// write code here
		ResultSet rs=null;
		Connection conn=null;
		PreparedStatement stmt=null;
		AuthorDAO authorDao=new AuthorDAO();
		int authorCode=0;
		try {
			String sql="select * from book_tbl where isbn=?";
			conn=DBUtil.getDBConnection();
			stmt=conn.prepareStatement(sql);
			stmt.setString(1,isbn);
			rs=stmt.executeQuery();
			if(rs.next()){
				mybean=new BookBean();
				mybean.setIsbn(rs.getString(1));
				mybean.setBookName(rs.getString(2));
				mybean.setBookType(rs.getString(3).charAt(0));
				authorCode=rs.getInt(4);
				mybean.setCost(rs.getFloat(5));
				
				mybean.setAuthor(authorDao.getAuthor(authorCode));
			}
			else 
				return null;
			
			
		} catch (Exception e) {
			// TODO: handle exception
			return null;
		}
		return mybean;
	}

}
