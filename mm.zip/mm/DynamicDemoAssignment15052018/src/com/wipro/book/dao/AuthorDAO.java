package com.wipro.book.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.wipro.book.bean.AuthorBean;
import com.wipro.book.util.DBUtil;


public class AuthorDAO {
	AuthorBean getAuthor(int authorCode) {
		AuthorBean author = null;
		// write code here
		ResultSet rs=null;
		Connection conn=null;
		PreparedStatement stmt=null;
		try {
			String sql="select * from author_tbl where author_code=?";
			conn=DBUtil.getDBConnection();
			stmt=conn.prepareStatement(sql);
			stmt.setInt(1, authorCode);
			rs=stmt.executeQuery();
			if(rs.next()){
				author=new AuthorBean();
				author.setAuthorCode(rs.getInt(1));
				author.setAuthorName(rs.getString(2));
				author.setContactNo(rs.getLong(3));
			}
		} catch (Exception e) {
			// TODO: handle exception
			return null;
		}
		return author;
	}

	AuthorBean getAuthor(String authorName) {
		AuthorBean author = null;
		// write code here
		ResultSet rs=null;
		Connection conn=null;
		PreparedStatement stmt=null;
		try {
			String sql="select * from author_tbl where author_name=?";
			conn=DBUtil.getDBConnection();
			stmt=conn.prepareStatement(sql);
			stmt.setString(1, authorName);
			rs=stmt.executeQuery();
			if(rs.next()){
				author=new AuthorBean();
				author.setAuthorCode(rs.getInt(1));
				author.setAuthorName(rs.getString(2));
				author.setContactNo(rs.getLong(3));
			}
		} catch (Exception e) {
			// TODO: handle exception
			return null;
		}
		return author;
	}
}
