package com.wipro.book.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wipro.book.bean.AuthorBean;
import com.wipro.book.bean.BookBean;
import com.wipro.book.service.Administrator;

/**
 * Servlet implementation class MainServlet
 */
public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public MainServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO write code here
		String msg="";
		ServletContext sc=getServletContext();
		RequestDispatcher rd=null;
		String input=request.getParameter("operation");
		System.out.println("Parameter Value:"+input);
		if(input.equalsIgnoreCase("AddBooks")==true){
			msg=this.addBook(request);
			
			if(msg.equalsIgnoreCase("SUCCESS")){
				rd=sc.getRequestDispatcher("/Menu.html");
			}
			if(msg.equalsIgnoreCase("FAILURE")){
				rd=sc.getRequestDispatcher("/Failure.html");
			}
			if(msg.equalsIgnoreCase("INVALID")){
				rd=sc.getRequestDispatcher("/Invalid.html");
			}
			rd=sc.getRequestDispatcher("/View.jsp");
			
			rd.forward(request, response);
		}
		if(input.equalsIgnoreCase("Search")==true){
			BookBean book=new BookBean(); 
			book=this.viewBook(request.getParameter("Search"));
			if(book==null){
				response.setContentType("text/html");
				response.sendRedirect("Invalid.html");
			}
			else{
				response.setContentType("text/html");
				//response.
				
				response.sendRedirect("View.jsp");
			}
		}
	}

	public BookBean viewBook(String isbn) {
		Administrator administrator = new Administrator();
		BookBean mybean = administrator.viewBook(isbn);
		// write code here
		return mybean;
	}

	public String addBook(HttpServletRequest request) {
		String result = "";
		// write code here
		BookBean book=new BookBean();
		AuthorBean author=new AuthorBean();
		book.setIsbn(request.getParameter("isbn"));
		book.setBookName(request.getParameter("bookName"));
		book.setBookType(request.getParameter("bookType").charAt(0));
		book.setCost(Float.parseFloat(request.getParameter("cost")));
		
		author.setAuthorName(request.getParameter("author"));
		book.setAuthor(author);
		Administrator administrator = new Administrator();
		result=administrator.addBook(book);
		System.out.println(result);
		return result;

	}

}
