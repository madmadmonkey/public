package com.wipro.book.service;

import com.wipro.book.bean.BookBean;
import com.wipro.book.dao.BookDAO;

public class Administrator {
	public String addBook(BookBean bookBean) {
		// write code here
		int result=0;
		if(bookBean==null)
			return "INVALID";
		
		if(bookBean.getBookName().isEmpty()==true)
			return "INVALID";
		
		if(bookBean.getIsbn().isEmpty()==true)
			return "INVALID";
		
/*		if(bookBean.getBookType()+""=="")
			return "INVALID";*/
		
		if(bookBean.getBookType()==' ')
			return "INVALID";
		System.out.println(bookBean.getBookType()!='G');
		
		if((bookBean.getBookType()!='G') && (bookBean.getBookType()!='T')) 
			return "INVALID";
		
		
		
		if(bookBean.getCost()==0)
			return "INVALID";
		
		if(bookBean.getAuthor().getAuthorName().isEmpty()==true)
			return "INVALID";
		
		BookDAO bookDao=new BookDAO();
		result=bookDao.createBook(bookBean);
		if(result>0)
			return "SUCCESS";
		else
			return "FAILURE";
	}

	public BookBean viewBook(String isbn) {
	
		// write code here
		BookDAO bookDao=new BookDAO();
		BookBean book=new BookBean();
		book=bookDao.fetchBook(isbn);
		if(book!=null && book.getIsbn().equalsIgnoreCase(isbn))
			return book;
		else
			return null;
	}

}
