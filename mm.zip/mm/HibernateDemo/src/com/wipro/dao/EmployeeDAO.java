package com.wipro.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.wipro.entity.Employee;

public class EmployeeDAO {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeDAO dao=new EmployeeDAO();
		dao.addEmployee();
		Employee emp=dao.getEmployee(102);
		if(emp!=null){
			System.out.println(emp);
		}
		else
			System.out.println("No such object found");
	}
	
	public void addEmployee(){
		Configuration cfg=new Configuration();
		SessionFactory sf=cfg.configure().buildSessionFactory();
		Session session=sf.openSession();
		Transaction transaction=session.beginTransaction();
		
		Employee e1=new Employee();
		//e1.setEmpNo(103);
		e1.setEmpName("mm");
		e1.setEmpGender('M');
		e1.setEmpSalary(21250.80);
		e1.setEmpDoj(new java.util.Date());
		session.save(e1);
		
		Employee e2=new Employee();
		//e2.setEmpNo(104);
		e2.setEmpName("dd");
		e2.setEmpGender('F');
		e2.setEmpSalary(11250.60);
		e2.setEmpDoj(new java.util.Date());
		
		session.save(e2);
		
		transaction.commit();
		session.close();
		
	}
	
	public Employee getEmployee(int eNo){
		Configuration config = new Configuration();
		SessionFactory sf=config.configure().buildSessionFactory();
		Session session=sf.openSession();
		
		Transaction tr=session.beginTransaction();
		Employee emp=(Employee)session.get(com.wipro.entity.Employee.class, eNo);
		System.out.println(emp.getEmpNo());
		System.out.println(emp.getEmpName());
		System.out.println(emp.getEmpGender());
		System.out.println(emp.getEmpSalary());
		session.close();
		return emp;
	}

}
