package com.wipro.book.dao;

import com.wipro.book.bean.AuthorBean;


public class AuthorDAO {
	AuthorBean getAuthor(int authorCode) {
		AuthorBean author = null;
		// write code here
		return author;
	}

	AuthorBean getAuthor(String authorName) {
		AuthorBean author = null;
		// write code here
		return author;
	}
}
