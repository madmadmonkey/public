package com.wipro.book.dao;

import com.wipro.book.bean.AuthorBean;
import com.wipro.book.bean.BookBean;

public class BookDAO {
	public int createBook(BookBean bookBean) {
		int count = 0;
		// write code here
		return count;
	}

	public BookBean fetchBook(String isbn) {
		BookBean mybean = null;
		// write code here
		return mybean;
	}

}
