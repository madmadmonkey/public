package com.wipro.book.service;

import com.wipro.book.bean.BookBean;

public class Administrator {
	public String addBook(BookBean bookBean) {
		// write code here
		return "";
	}

	public BookBean viewBook(String isbn) {
	
		// write code here
		return null;
	}

}
