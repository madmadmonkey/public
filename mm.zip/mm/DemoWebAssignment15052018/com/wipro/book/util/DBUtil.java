package com.wipro.book.util;

import java.sql.Connection;

public class DBUtil {
	public static Connection getDBConnection() {
		Connection con = null;
        //write code here
		return con;
	}
}
