package com.wipro.candidate.util;

import java.sql.Connection;


public class DBUtil {
public static Connection getDBConn()
{
	Connection con=null;
	//write code here
	return con;
}
}
