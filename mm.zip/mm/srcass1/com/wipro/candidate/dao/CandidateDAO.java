package com.wipro.candidate.dao;


import java.util.ArrayList;

import com.wipro.candidate.bean.CandidateBean;


public class CandidateDAO {
	public String addCandidate(CandidateBean studentBean)
	{
			String status="";
			//write code here
			return status;
	}
	public ArrayList<CandidateBean> getByResult(String criteria)
	{
		ArrayList<CandidateBean> list=new ArrayList<CandidateBean>();
		//write code here
		return list;
	}
	public String generateCandidateId (String name)
	{
		String id="";
		//write code here
		return id;
	}
}
