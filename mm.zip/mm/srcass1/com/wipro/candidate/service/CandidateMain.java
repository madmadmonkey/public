package com.wipro.candidate.service;

import java.util.ArrayList;


import com.wipro.candidate.bean.CandidateBean;


public class CandidateMain {

	/**
	 * @param args
	 */
	public String addCandidate(CandidateBean studBean)
	{
		String result="";
	    //write code here
	    return result;
		
	}
	public ArrayList<CandidateBean> displayAll(String criteria)
	{
		return null;
		
		//write code here
		
	}
	public static void main(String[] args) {
		//write code here
	}

}
