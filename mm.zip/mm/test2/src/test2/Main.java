package test2;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s="manik";
System.out.println(s.substring(0, 2));
	}

}
