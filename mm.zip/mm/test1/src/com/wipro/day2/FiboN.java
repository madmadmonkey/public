package com.wipro.day2;

import java.util.HashSet;
import java.util.Set;

public class FiboN {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=12;
		//System.out.println(fiboN(n));
		System.out.println("  ");
		System.out.println(func(12344321));
		
	}
	private static boolean isPrime(int num) {
        if (num < 2) return false;
        if (num == 2) return true;
        if (num % 2 == 0) return false;
        for (int i = 3; i * i <= num; i += 2)
            if (num % i == 0) return false;
        return true;
}
	static int func(int num)
	{

		int arr[]=new int[10];
		int count=0;
		while(num>0){
			
			arr[num%10]=arr[num%10]+1;
			num=num/10;
		}
			
		for(int i=0;i<10;i++){
			if(arr[i]==1)
				count++;
		}
		return count;
	}

}
