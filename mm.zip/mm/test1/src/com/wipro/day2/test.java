package com.wipro.day2;

import java.util.HashMap;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String input1="All Zebras are Black & White";//"madam abcd & !";
		input1=input1.toLowerCase();
		System.out.println(input1);
		int i=0;
		int sum=0;
		int vowelSum=0;
		HashMap<Character,Integer> map=new HashMap<Character,Integer>();
		String atoz[]={" ","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"};
		for(i=0;i<atoz.length;i++){
			map.put(atoz[i].charAt(0),i);
		}
		map.put('&', 0);map.put('!', 0);map.put(',', 0);map.put('\'', 0);
		for(i=0;i<input1.length();i++){
			char c=input1.charAt(i);
			if(c=='a'||c=='e'||c=='i'||c=='o'||c=='u'){
				vowelSum=vowelSum+map.get(c);
			}
			else
				sum=sum+map.get(c);
		}
		System.out.println("sum="+sum+" v="+vowelSum+" total="+(sum+vowelSum));
		char c='0';
		int t=c;
		System.out.println(t);
	}	
}
