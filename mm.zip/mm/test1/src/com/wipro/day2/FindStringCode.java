package com.wipro.day2;

public class FindStringCode {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String input1="WORLD";
		
		String arr[]=retWord(input1);
		String msg="";
		for(int i=0;i<arr.length;i++){
			StringBuffer s1=new StringBuffer(arr[i]);
			
			StringBuffer s2=new StringBuffer(s1);
			s2.reverse();
			System.out.println(s1);
			System.out.println(s2);
			int d=0;
			for(int j=0;j<(s1.length=/2);j++){
				System.out.println(d);
				d+=Math.abs(s1.charAt(j)-s2.charAt(j));
			}
			//if(s1.length()%2!=0){
				//d+=Math.abs(s1.charAt((s1.length()%2)+1));
			//}
			//msg=msg+Integer.toString(d);
			System.out.println(d);
		}
		

	}
	
	public static String[] retWord(String input1){
		return input1.split(" ");
	}

}
