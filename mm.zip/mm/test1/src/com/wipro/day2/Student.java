package com.wipro.day2;

public class Student implements Comparable {
	int rno;
	String name;
	public Student(int rno, String name) {
		super();
		this.rno = rno;
		this.name = name;
	}
	public int compareTo(Object o){
		Student s=(Student) o;
		if(this.rno<s.rno)
			return -1;
		else if(this.rno==s.rno)
			return 0;
		else
			return 1;
	}
}
/*
 * int i1=4,i2=5,i3=2;
 * int to=0;
loop(1-4){
to=to+i2*i;
i2=i2+i3
}
*/
