package com.wipro.day2;

import java.util.Iterator;
import java.util.TreeSet;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet<Student> student =new TreeSet<Student>();
		Student s1=new Student(12, "MM");
		Student s2=new Student(10, "AA");
		Student s3=new Student(14, "BB");
		student.add(s1);
		student.add(s2);
		student.add(s3);
		
		Iterator<Student> it=student.iterator();
		while(it.hasNext()){
			Student s=it.next();
			System.out.println(s.rno);
			System.out.println(s.name);
		}
		
	}
}