package com.wipro.day2;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class HashMapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<String,Integer> map=new HashMap<String,Integer>();
		map.put("One", 1);
		map.put("Two", 2);		
		int i=map.get("One");
		System.out.println(i);
		Set<String> s=map.keySet();
		Iterator it=s.iterator();
		while(it.hasNext()){
			String key=(String) it.next();
			int val=map.get(key);
			System.out.println(key+" "+val);
		}
		
	}

}
