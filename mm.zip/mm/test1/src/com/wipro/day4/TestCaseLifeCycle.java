package com.wipro.day4;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

public class TestCaseLifeCycle {
	public TestCaseLifeCycle(){
		System.out.println("Constructor called");
	}
	@BeforeClass
	public static void before(){
		System.out.println("Before Class");
	}
	@AfterClass
	public static void after(){
		System.out.println("after Class");
	}
	@Test
	public void test1(){
		System.out.println("Test 1");
	}
	@Test
	public void test2(){
		System.out.println("Test 2");
	}
}
