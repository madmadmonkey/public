package com.wipro.day4;

import java.util.Date;

@SuppressWarnings({"unused","deprecation"})
public class Main {
	public static void main(String[] args) {
		Test4 t=new Test4();
		//System.out.println(t.toString());
		System.out.println(t);
		
		int x=0;
		Date d=new Date();
		int day=d.getDay();
		System.out.println(day);
	}
}
