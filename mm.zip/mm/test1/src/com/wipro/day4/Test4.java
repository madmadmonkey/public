package com.wipro.day4;

/**
 * 
 * @author training47
 *
 */
public class Test4 {
	@Override
	public String toString(){
		return "HI";
	}
	

}
