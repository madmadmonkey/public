package com.wipro.day4;
import static org.junit.Assert.*;

import org.junit.Ignore;
import org.junit.Test;

import com.wipro.maths.Arithmetic;

public class ArithmeticTest {
	@Ignore
	@Test
	public void test() {
		fail("Not yet implemented");
	}
	@Test
	public void add() {
		Arithmetic obj=new Arithmetic();
		obj.a=5;
		obj.b=6;
		int exp=11;
		assertEquals("Addition failed", exp,obj.add());
		
	}
	@Ignore
	@Test
	public void sub() {
		Arithmetic obj=new Arithmetic();
		obj.a=5;
		obj.b=6;
		int exp=-1;
		assertEquals("Subtraction failed", exp,obj.sub());
		
	}
	@Test
	public void testSame(){
		String a="Hello";
		String b= "Hello";//new String("Hello");
		//assertEquals(a,b);
		assertSame(a, b);
	}

}
