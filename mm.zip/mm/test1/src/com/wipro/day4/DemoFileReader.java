package com.wipro.day4;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class DemoFileReader {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//int i=0;
		String str="";
		try {
			
			FileReader fr=new FileReader("D:/mm/demo_file.txt");
			BufferedReader br=new BufferedReader(fr);
			
			while((str=br.readLine())!=null){
				//char ch=(char)i;
				System.out.println(str);
			}
			fr.close();
			br.close();
			System.out.printf("%nEnd Reading");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
