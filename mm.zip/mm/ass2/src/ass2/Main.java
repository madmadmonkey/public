package ass2;

import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		int input1=122;
		int input2=131;
		int input3=121;
		int input4=6788;
		int input5=898;
		System.out.println(findStable(input1));
		System.out.println(findStable(input2));
		System.out.println(findStable(input3));
		System.out.println(findStable(input4));
		
		System.out.println(findStable(input5));		
	
		System.out.println(findPassword(input1,input2,input3,input4,input5));
	}
	
	static int findPassword(int input1,int input2,int input3,int input4,int input5){
		int password=0;
		//int arrStable[]=new int[5];
		ArrayList<Integer> arrStable=new ArrayList<Integer>();
		
		int number[]={input1,input2,input3,input4,input5};
		int maxStable=0;
		int minStable=0;
		
		for(int i=0;i<5;i++){
			if(findStable(Math.abs(number[i]))==true){
				arrStable.add(number[i]);
				
			}
			
		}
		if(arrStable.size()==0)
			return 0;
		System.out.println("Stable "+arrStable);
		maxStable=findMax(arrStable);
		System.out.println("Max"+maxStable);
		minStable=findMin(arrStable);
		System.out.println("Min"+minStable);
		
		password=maxStable+minStable;
		System.out.println("Password"+password);
		
		return password;
	}

	static boolean findStable(int num){
		int freq=-1;
		int arr[]=new int[10];
		while(num>0){
			arr[num%10]++;
			num/=10;
		}
		for(int i=0;i<=9;i++){
			if(arr[i]==0)
				continue;
			if(freq==-1){
				freq=arr[i];
				continue;
				
			}
			if(freq!=arr[i])
				return false;
			
		}
		return true;
	}
	static int findMax(ArrayList<Integer> arrStable){
		int max=-99999;
		for(int i=0;i<arrStable.size();i++){
			if(arrStable.get(i)>max)
				max=arrStable.get(i);
		}
		return max;
	}
	static int findMin(ArrayList<Integer> arrStable){
		int min=arrStable.get(0);
		for(int i=0;i<arrStable.size();i++){
			if(arrStable.get(i)<min)
				min=arrStable.get(i);
		}
		return min;
	}

}
