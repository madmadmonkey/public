package com.wipro.day4;

import java.io.Serializable;

public class Student implements Serializable{
	static int rno;
	transient String name;
	public int getRno() {
		return rno;
	}
	public void setRno(int rno) {
		this.rno = rno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	

}
