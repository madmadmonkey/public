package com.wipro.day4;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class StudentSerialDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s=new Student();
		s.setName("MM");
		s.setRno(1011);
		try {
			FileOutputStream fo= new FileOutputStream("D://obj.txt");
			ObjectOutputStream oos =new ObjectOutputStream(fo);
			oos.writeObject(s);
			System.out.println("Writing Done");
			oos.close();
			fo.close();
		} catch (FileNotFoundException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		catch (IOException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

}
