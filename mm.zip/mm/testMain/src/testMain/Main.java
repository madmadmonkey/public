package testMain;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="";
		String s2=null;
		String s3="manik";
		char ch=' ';
		if(s1.isEmpty()==true)
			System.out.println("S1 Empty");
		if(s1.isEmpty()==true)
			System.out.println("S1 Empty");
		//if(ch=='G')
			System.out.println(ch);
			
	}

}
