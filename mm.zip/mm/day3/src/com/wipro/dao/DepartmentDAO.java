package com.wipro.dao;

import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.wipro.bean.Department;
import com.wipro.util.DBConnection;

public class DepartmentDAO {
	public String insertDepartment(Department dept){

		try {
			DBConnection dbConn= new DBConnection();
			Connection conn=dbConn.getConnection();
			Statement stmt=conn.createStatement();
			
			String sql="insert into dept values("+
					dept.getDeptNo()+",'"+dept.getdName()+"','"+dept.getLocation()+"')";
			
			int result=stmt.executeUpdate(sql);
			if(result==1)
				return "success";
			else
				return "failure";
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return null;
		
	}
	public Department getDepartment(int deptno) throws SQLException{
		ResultSet rs=null;
		Department dept=null;
		DBConnection dbConn=null;
		Connection conn=null;
		try {
			dbConn= new DBConnection();
			conn=dbConn.getConnection();
			Statement stmt=conn.createStatement();
			String sql="select * from dept where deptno="+deptno;
			rs=stmt.executeQuery(sql);
			if(rs.next()){
				dept=new Department(rs.getInt(1), rs.getString(2), rs.getString(3));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		conn.close();
		rs.close();
		return dept;
	}
	public ArrayList<Department> getDepartment() throws SQLException{
		ArrayList<Department> list=new ArrayList<Department>();
		ResultSet rs=null;
		Department dept=null;
		DBConnection dbConn=null;
		Connection conn=null;
		try{
			dbConn= new DBConnection();
			conn=dbConn.getConnection();
			Statement stmt=conn.createStatement();
			String sql="select * from dept";
			rs=stmt.executeQuery(sql);
			while(rs.next()){
				dept=new Department(rs.getInt(1), rs.getString(2), rs.getString(3));
				list.add(dept);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		conn.close();
		rs.close();
		return list;
	}
}
