package com.wipro.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.wipro.bean.Department;
import com.wipro.util.DBConnection;

public class DepartmentDynamicDAO {
	Department dept=null;
	DBConnection dbConn=null;
	Connection conn= null;
	PreparedStatement ps=null;
	
	
	public DepartmentDynamicDAO() throws SQLException {
		dbConn= new DBConnection();
		conn= dbConn.getConnection();
	ps=conn.prepareStatement("insert into dept values(?,?,?)");
	}
	
	
	public String insertDepartment(Department dept){

		try {
			ps.setInt(1, dept.getDeptNo());
			ps.setString(2, dept.getdName());
			ps.setString(3, dept.getLocation());
			

			
			int result=ps.executeUpdate();
			if(result==1)
				return "success";
			else
				return "failure";
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return "fail";
		
	}
	public String updateDepartment(String loc, int deptNo) throws SQLException{
		dbConn= new DBConnection();
		conn= dbConn.getConnection();
		ps=conn.prepareStatement("update dept set loc=? where deptno=?");

		try {
			
			ps.setString(1, loc);
			ps.setInt(2, deptNo);
			

			
			int result=ps.executeUpdate();
			if(result==1)
				return "success";
			else
				return "failure";
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return "fail";
		
	}
	//create procedure updateDept(P_loc varchar2,p_dno number) as begin update dept set loc=p_loc where deptno=p_dno; end;/
}
