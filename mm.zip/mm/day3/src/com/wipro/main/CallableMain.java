package com.wipro.main;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import com.wipro.util.DBConnection;

public class CallableMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			DBConnection dbConn= new DBConnection();
			Connection conn=dbConn.getConnection();
			String sql="{call updateDept(?,?)}";
			CallableStatement cs=conn.prepareCall(sql);
			cs.setString(1, "GNDC");
			cs.setInt(2, 100);
			
			if(cs.execute()==true)
				System.out.println("Procedure run");
			else
				System.out.println("Procedure did not run");
		} catch (SQLException e) {
			// TODO: handle exception
		}
	}

}
//create table emp_test as select empno
