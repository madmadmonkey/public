package com.wipro.main;

import java.sql.SQLException;

import com.wipro.dao.DepartmentDynamicDAO;

public class PreparedMain {

	public static void main(String[] args) {
	
		String msg="";
		try {
			DepartmentDynamicDAO ddao=new DepartmentDynamicDAO();
			//Department dobj=new Department(70,"Testing","KOL");
			
			///msg=ddao.insertDepartment(dobj);
			
			msg=ddao.updateDepartment("BLR", 70);
			System.out.println(msg);
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

}
