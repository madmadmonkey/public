package com.wipro.main;

import java.sql.SQLException;
import java.util.ArrayList;

import com.wipro.bean.Department;
import com.wipro.dao.DepartmentDAO;


public class Main {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		Department dobj=new Department(70,"Testing","KOL");
		
		DepartmentDAO dao=new DepartmentDAO();
		
		ArrayList<Department> list=new ArrayList<Department>();
		
		dao.insertDepartment(dobj);
		
		dobj=dao.getDepartment(50);
		list=dao.getDepartment();
		//System.out.println(dobj);
		for(Department ob: list){
			System.out.println(ob);
		}
	}

}
