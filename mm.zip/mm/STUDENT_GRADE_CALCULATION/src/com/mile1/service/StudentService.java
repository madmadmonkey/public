package com.mile1.service;

import com.mile1.bean.Student;

public class StudentService {
	public int findNumberOfNullMarks(Student data[])
	{
		
	 // write code here
		int countNull=0;
		int dataSize=data.length;
		
		for(int i=0;i<dataSize;i++){
		
			if(data[i]!=null&&data[i].getMarks()==null)
				{
				countNull++;
				}
		}

		
		return countNull;
		
	}
	public int findNumberOfNullNames(Student data [])
	{
	 // write code here
		int countNull=0;
		int dataSize=data.length;
		for(int i=0;i<dataSize;i++){
			if(data[i]!=null&&data[i].getName()==null)
				countNull++;
		}

		
		return countNull;
		
	}
	public int findNumberOfNullObjects(Student data [])
	{
	 // write code here
		int countNull=0;
		int dataSize=data.length;
		
		for(int i=0;i<dataSize;i++){
			///////////System.out.println("printing data" +data[i]);
			if(data[i]==null)
				countNull++;
		}

		
		return countNull;
	}

}
