package com.mile1.service;

import com.mile1.bean.Student;
import com.mile1.exception.*;

public class StudentReport {
	public String findGrade(Student studentObject)
	{
		int marks[]=studentObject.getMarks();
		
		int totalMarks=marks[0]+marks[1]+marks[2];
		
		if(marks[0]<35||marks[1]<35||marks[2]<35)
			return "F";
		else{
			if(totalMarks<=150)
				return "D";
			if(totalMarks>150&&totalMarks<=200)
				return "C";
			if(totalMarks>200&&totalMarks<=250)
				return "B";
			if(totalMarks>250&&totalMarks<=350)
				return "A";
		}
		return null;
		
	}
	public String validate(Student studentObject) throws NullStudentException, NullNameException, NullMarksArrayException
	{
		if (studentObject==null)
		{
			throw new NullStudentException();
		}
		else{
			if(studentObject.getName()==null)
				throw new NullNameException();
			if(studentObject.getMarks()==null)
				throw new NullMarksArrayException();
		}

		return findGrade(studentObject);
		
	}

}
