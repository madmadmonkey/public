package com.wipro.bus.util;

@SuppressWarnings("serial")
public class InvalidInputException extends Exception {

	@Override
	public String toString() {
		
		return "INVALID INPUT";
	}
	
	

}
