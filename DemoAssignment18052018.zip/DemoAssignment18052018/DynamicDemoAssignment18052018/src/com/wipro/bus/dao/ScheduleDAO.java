package com.wipro.bus.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


import com.wipro.bus.bean.ScheduleBean;
import com.wipro.bus.util.DBUtil;


public class ScheduleDAO {

	public String createSchedule(ScheduleBean scheduleBean) {
		int rowsInserted = 0;
		String result = "SUCCESS";
		// write code here
		//ResultSet rs=null;
		Connection conn=null;
		PreparedStatement stmt=null;
		try {
			String sql="insert into schedule_tbl values(?,?,?,?,?)";
			conn=DBUtil.getDBConnection();
			stmt=conn.prepareStatement(sql);
			stmt.setString(1, scheduleBean.getScheduleId());
			stmt.setString(2, scheduleBean.getSource());
			stmt.setString(3, scheduleBean.getDestination());
			stmt.setString(4, scheduleBean.getStartTime());
			stmt.setString(5, scheduleBean.getArrivalTime());
			rowsInserted=stmt.executeUpdate();
			if(rowsInserted>0){
				return "SUCCESS";
			}
		} catch (Exception e) {
			// TODO: handle exception
			return "FAILURE";
		}
		return result;
	}

	public String generateID(String source, String destination) throws SQLException {
		//int seqNumber = 0;
		String result = null;
		String id="";
		// write code here
		String src=source.toUpperCase().substring(0, 2);
		String dest=destination.toUpperCase().substring(0, 2);
		
		ResultSet rs=null;
		String sql="select schedule_seq.nextval from dual";
		Connection conn=null;
		Statement stmt=null;
		
		try {
			conn=DBUtil.getDBConnection();
			stmt=conn.createStatement();
			rs=stmt.executeQuery(sql);
			if(rs.next())
				id=Integer.toString(rs.getInt(1));
			//System.out.println(id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		conn.close();
		stmt.close();
		rs.close();
		result=new String(src+dest+id);
		
		return result;
	}

	public ArrayList<ScheduleBean> viewSchedule(String source,
			String destination) {

		ArrayList<ScheduleBean> schedules = new ArrayList<ScheduleBean>();
		// write code here
		ResultSet rs=null;
		Connection conn=null;
		PreparedStatement stmt=null;
		try {
			String sql="select * from schedule_tbl where source=? and destination=?";
			conn=DBUtil.getDBConnection();
			stmt=conn.prepareStatement(sql);
			stmt.setString(1, source);
			stmt.setString(2, destination);
			
			rs=stmt.executeQuery();
			while(rs.next()){
				ScheduleBean sc=new ScheduleBean();
				sc.setScheduleId(rs.getString(1));
				sc.setSource(source);
				sc.setDestination(destination);
				sc.setStartTime(rs.getString(4));
				sc.setArrivalTime(rs.getString(5));
				schedules.add(sc);
			}
		} catch (Exception e) {
			// TODO: handle exception
			return null;
		}
		return schedules;
	}

}
