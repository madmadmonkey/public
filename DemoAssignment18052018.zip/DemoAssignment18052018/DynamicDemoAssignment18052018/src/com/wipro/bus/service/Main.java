package com.wipro.bus.service;

import java.sql.SQLException;

import com.wipro.bus.bean.ScheduleBean;

public class Main {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		Administrator ad=new Administrator();
		ScheduleBean sb=new ScheduleBean();
		//sb.setSource("Delhi");
		//sb.setDestination("Chennai");
		System.out.println(ad.addSchedule(sb));
	}

}
