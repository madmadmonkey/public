package com.wipro.bus.service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.wipro.bus.bean.ScheduleBean;
import com.wipro.bus.dao.ScheduleDAO;
import com.wipro.bus.util.InvalidInputException;

public class Administrator {

	public String addSchedule(ScheduleBean scheduleBean) throws  SQLException {
		String result = null;
		// write code here
		String id="";
		try {
			if(scheduleBean==null)
				throw new InvalidInputException();
			if(scheduleBean.getSource()==null)
				throw new InvalidInputException();
			if(scheduleBean.getDestination()==null)
					throw new InvalidInputException();
			if(scheduleBean.getSource().isEmpty()==true)
				throw new InvalidInputException();
			
			if(scheduleBean.getDestination().isEmpty()==true)
				throw new InvalidInputException();
			
			if(scheduleBean.getSource().length()<2)
				throw new InvalidInputException();
			
			if(scheduleBean.getDestination().length()<2)
				throw new InvalidInputException();
			
		} catch (InvalidInputException e) {
			// TODO: handle exception
			return "INVALID INPUT";
		}

		
		if(scheduleBean.getSource().equalsIgnoreCase(scheduleBean.getDestination())==true){
			return "Source and Destination Same";
			
		}
		
		ScheduleDAO sDao=new ScheduleDAO();
		id=sDao.generateID(scheduleBean.getSource(), scheduleBean.getDestination());
		
		scheduleBean.setScheduleId(id);
		result=sDao.createSchedule(scheduleBean);
		
		return result;
	}

	public ArrayList<ScheduleBean> viewSchedule(String source,
			String destination) {
		ArrayList<ScheduleBean> sb = new ArrayList<ScheduleBean>();
		if(source==null||destination==null)
			return null;
		if(source.isEmpty()==true)
			return null;
		
		if(source.isEmpty()==true)
			return null;
		
		if(source.length()<2)
			return null;
		
		if(source.length()<2)
			return null;
		if(source.equalsIgnoreCase(destination)==true)
			return null;
		// write code here
		/*ResultSet rs=null;
		Connection conn=null;
		PreparedStatement stmt=null;
		try {
			String sql="select * from schedule_tbl where source=? and destination=?";
			conn=DBUtil.getDBConnection();
			stmt=conn.prepareStatement(sql);
			stmt.setString(1, source);
			stmt.setString(2, destination);
			
			rs=stmt.executeQuery();
			while(rs.next()){
				ScheduleBean sc=new ScheduleBean();
				sc.setScheduleId(rs.getString(1));
				sc.setSource(source);
				sc.setDestination(destination);
				sc.setStartTime(rs.getString(4));
				sc.setArrivalTime(rs.getString(5));
				sb.add(sc);
			}
		} catch (Exception e) {
			// TODO: handle exception
			return null;
		}
	
*/
		ScheduleDAO sDao=new ScheduleDAO();
		sb=sDao.viewSchedule(source, destination);
		if(sb.isEmpty())
			return null;
		
		return sb;
	}

}
