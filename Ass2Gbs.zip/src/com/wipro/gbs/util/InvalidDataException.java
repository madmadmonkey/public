package com.wipro.gbs.util;

public class InvalidDataException extends Exception {
	public String toString()
	{
		return "INVALID DATA";
	}

}
