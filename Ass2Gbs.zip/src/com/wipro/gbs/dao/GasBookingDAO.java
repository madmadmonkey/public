package com.wipro.gbs.dao;

import com.wipro.gbs.bean.GasBookingBean;

public class GasBookingDAO {
	
	public int generateBookingNumber()
	{
		//Write your code here
		return -1;
		
	}
	public String createBooking(GasBookingBean bean)
	{
		//Write your code here
		return "";
		
	}
	public boolean canNewBookingBeDone(String username)
	{
		//Write your code here	
		return false;
	}
}
