package com.wipro.gbs.service;

import com.wipro.gbs.bean.GasBookingBean;


public class Administrator {
public static void main(String[] args) {
	//Write your code here
}
public String createBooking(GasBookingBean bean)
{
	//Write your code here
	return "";
}
}
